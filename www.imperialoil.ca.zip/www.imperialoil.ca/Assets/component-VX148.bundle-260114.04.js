(window.webpackJsonp = window.webpackJsonp || []).push([
    [66, 32], {
        132: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var s = i(94);
            var n = ["a[href]:not([disabled])", "button:not([disabled])", "textarea:not([disabled])", 'input[type="text"]:not([disabled])', 'input[type="radio"]:not([disabled])', 'input[type="checkbox"]:not([disabled])', 'select:not([disabled]):not([tabindex="-1"])', '[tabindex]:not([tabindex="-1"])'],
                a = function() {
                    function t(e) {
                        var i = e.html,
                            a = void 0 === i ? document.body : i,
                            o = e.reloaded,
                            l = void 0 !== o && o,
                            r = e.selectorsList,
                            c = void 0 === r ? n : r,
                            h = e.defaultFocus,
                            u = e.ignoreElement;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.html = a, this.defaultFocus = h, this.body = (0, s.qs)("body"), this.KEYCODE_TAB = 9, this.selectorsList = c.join(), this.ignoreElement = u, this.hiddenElements = [], this.setFocusableElements(), this.trapFocusReference = this.trapFocus.bind(this), l || (this.defaultFocus ? this.defaultFocus.focus() : this.firstFocusableEl.focus()), (0, s.$on)(window, "keydown", this.trapFocusReference)
                    }
                    return t.prototype.trapFocus = function(t) {
                        ("Tab" === t.key || t.keyCode === this.KEYCODE_TAB) && (t.shiftKey ? document.activeElement === this.firstFocusableEl && (this.lastFocusableEl.focus(), t.preventDefault()) : document.activeElement === this.lastFocusableEl && (this.firstFocusableEl.focus(), t.preventDefault()))
                    }, t.prototype.setFocusableElements = function() {
                        var t = this;
                        this.focusableElements = (0, s.qsa)(this.selectorsList, this.html), this.ignoreElement && (this.focusableElements = Array.from(this.focusableElements).filter((function(e) {
                            return !(0, s.hasClass)(e, t.ignoreElement)
                        })));
                        var e = this.focusableElements;
                        this.firstFocusableEl = e[0], this.lastFocusableEl = this.focusableElements[this.focusableElements.length - 1], this.setMobileFocusLoop()
                    }, t.prototype.removeTrapFocus = function() {
                        (0, s.forEach)(this.hiddenElements, (function(t) {
                            t.removeAttribute("aria-hidden"), t.removeAttribute("inert")
                        })), (0, s.$off)(window, "keydown", this.trapFocusReference)
                    }, t.prototype.setMobileFocusLoop = function() {
                        for (var t = this.html; t !== this.body;) {
                            for (var e = t.parentNode.childNodes, i = 0; i < e.length; i += 1) {
                                var n = e[i];
                                n && n.classList && (0, s.hasClass)(n, "skip-content") || n.id && "onetrust-consent-sdk" === n.id || n !== t && n.setAttribute && (n.setAttribute("inert", ""), n.setAttribute("aria-hidden", "true"), this.hiddenElements = [].concat(this.hiddenElements, [n]))
                            }
                            t = t.parentNode
                        }
                    }, t
                }();
            e.default = a
        },
        167: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var s = i(94),
                n = l(i(132)),
                a = l(i(131)),
                o = l(i(606));

            function l(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            var r = function() {
                function t(e) {
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.urlParams = {
                        url: (0, s.getUrlParams)()
                    }, this.html = e, this.GSClass = "globalSelectorV2", this.GSData = JSON.parse(JSON.stringify(window.XOM.GLOBAL)), this.bodyScroll = (0, s.qs)("body"), this.strings = this.html.dataset, this.isTabletMin = !1, this.panelTitle = "", this.launcherBtn = null, this.location = window.location, this.GlobalData = {
                        GlobalTitle: this.GSData.GlobalTitle,
                        GlobalUrl: this.GSData.GlobalUrlLink,
                        GlobalUrlTarget: this.GSData.GlobalUrlTarget
                    }, this.sitesMatchesHost = [], this.currentViewObj = this.getCurrentlyViewing(), this.isRtl = "rtl" === document.querySelector("html").getAttribute("dir"), this.analytics = new a.default;
                    var i = window.matchMedia("(min-width: 768px)");
                    i.addListener(this.handleMediaQueryChange.bind(this)), this.handleMediaQueryChange(i), this.GSMarkup = new o.default({
                        GSClass: this.GSClass
                    }), this.html.innerHTML = this.GSMarkup.createMarkup(this.GSData.Regions, this.strings, this.GlobalData), this.sections = (0, s.qsa)("." + this.GSClass + "--section", this.html), this.countryListWapper = (0, s.qs)("." + this.GSClass + "--countryList", this.html), this.globalBtn = (0, s.qs)("." + this.GSClass + "--globalBtn", this.html), this.handleEvents(), this.isTabletMin && this.showCurrentlyViewingElement(), this.openIsUrlParams()
                }
                return t.prototype.openIsUrlParams = function() {
                    if (1 === this.urlParams.url.length) try {
                        this.urlParams.url[0].value = decodeURIComponent(this.urlParams.url[0].value)
                    } catch (t) {
                        this.urlParams.url[0].value = ""
                    }
                    this.urlParams.url.length > 0 && this.urlParams.url[0].key && "query" === this.urlParams.url[0].key && this.toggleState()
                }, t.prototype.handleMediaQueryChange = function(t) {
                    this.isTabletMin = t.matches
                }, t.prototype.handleEvents = function() {
                    var t = this,
                        e = (0, s.qsa)("." + this.GSClass + "--headerBtn", this.html),
                        i = (0, s.qsa)("." + this.GSClass + "--backBtn", this.html);
                    if ((0, s.forEach)(e, (function(e) {
                            (0, s.$on)(e, "click", (function(i) {
                                t.toggleAccordionState(e, (function(s) {
                                    t.setAnalytics("click - tier 1", e.innerText, {
                                        event: s ? "region_dropdown_close_click" : "region_dropdown_open_click",
                                        module_name: "globalSelectorV2",
                                        link_text: e.innerText.trim(),
                                        link_url: i.target.getAttribute("href") || void 0
                                    })
                                }))
                            }))
                        })), this.handleCountryEvents(this.html), (0, s.forEach)(i, (function(e) {
                            (0, s.$on)(e, "click", t.mobileBackButton.bind(t))
                        })), (0, s.$on)(document, "openGlobal", this.toggleState.bind(this)), (0, s.$on)((0, s.qs)("." + this.GSClass + "--navClose"), "click", this.toggleState.bind(this)), (0, s.$on)(window, "keydown", this.handleKeyPress.bind(this)), this.globalBtn) {
                        var n = this.globalBtn.innerText;
                        (0, s.$on)(this.globalBtn, "click", (function() {
                            return t.setAnalytics("corporate click", n)
                        }))
                    }
                }, t.prototype.handleCountryEvents = function(t) {
                    var e = this,
                        i = (0, s.qsa)("." + this.GSClass + "--country", t);
                    (0, s.forEach)(i, (function(t) {
                        (0, s.$on)(t, "click", (function(i) {
                            e.getCountryData(t), e.setAnalytics("click - tier 2", t.innerText, {
                                event: "country_dropdown_click",
                                module_name: "globalSelectorV2",
                                link_text: t.innerText.trim(),
                                link_url: i.target.getAttribute("href") || void 0
                            })
                        }))
                    }))
                }, t.prototype.handleSitesEvents = function(t) {
                    var e = this,
                        i = (0, s.qs)(".globalSelectorV2--item.openItem", this.html),
                        n = (0, s.qsa)(".globalSelectorV2--siteLink", i),
                        a = (0, s.qsa)(".globalSelectorV2--siteLink", t);
                    (0, s.forEach)(a, (function(t) {
                        var i = t.getAttribute("href");
                        (0, s.$on)(t, "click", (function(t) {
                            return e.setAnalytics("click - site link", i, {
                                event: "global_site_link_click",
                                module_name: "globalSelectorV2",
                                link_text: t.target.innerText.trim(),
                                link_url: i
                            })
                        })), 1 === n.length && (0, s.$on)(t, "keydown", e.flexibleSubitem.bind(e)), t === a[0] && 1 !== n.length && (0, s.$on)(t, "keydown", e.previousCountry.bind(e)), t === a[a.length / 2 - 1] && 1 !== n.length && (0, s.$on)(t, "keydown", e.nextCountry.bind(e))
                    }))
                }, t.prototype.nextCountry = function(t) {
                    var e = (0, s.qs)(".globalSelectorV2--item.openItem", this.html),
                        i = (0, s.qsa)(".globalSelectorV2--siteLink", e),
                        n = (0, s.qsa)(".globalSelectorV2--country", e),
                        a = (0, s.qs)(".globalSelectorV2--country.font--semibold", this.html);
                    9 !== t.keyCode || t.shiftKey || (void 0 !== n[(0, s.getIndex)(a, n) + 1] && n[(0, s.getIndex)(a, n)].focus(), (0, s.forEach)(i, (function(t) {
                        t.setAttribute("tabindex", "-1")
                    })))
                }, t.prototype.previousCountry = function(t) {
                    var e = (0, s.qs)(".globalSelectorV2--item.openItem", this.html),
                        i = (0, s.qsa)(".globalSelectorV2--siteLink", e),
                        n = (0, s.qsa)(".globalSelectorV2--country", e),
                        a = (0, s.qs)(".globalSelectorV2--country.font--semibold", this.html);
                    9 === t.keyCode && t.shiftKey && (void 0 !== n[(0, s.getIndex)(a, n)] && n[(0, s.getIndex)(a, n) + 1].focus(), (0, s.forEach)(i, (function(t) {
                        t.setAttribute("tabindex", "-1")
                    })))
                }, t.prototype.flexibleSubitem = function(t) {
                    var e = (0, s.qs)(".globalSelectorV2--item.openItem", this.html),
                        i = (0, s.qsa)(".globalSelectorV2--siteLink", e),
                        n = (0, s.qsa)(".globalSelectorV2--country", e),
                        a = (0, s.qs)(".globalSelectorV2--country.font--semibold", this.html);
                    9 === t.keyCode && (t.shiftKey ? n[(0, s.getIndex)(a, n) + 1].focus() : n[(0, s.getIndex)(a, n)].focus(), (0, s.forEach)(i, (function(t) {
                        t.setAttribute("tabindex", "-1")
                    })))
                }, t.prototype.handleKeyPress = function(t) {
                    27 === t.keyCode && (0, s.hasClass)(this.html, "show") && (this.toggleState(t), (0, s.$off)(window, "keydown", this.handleKeyPress.bind(this)))
                }, t.prototype.toggleState = function(t) {
                    if (this.urlParams.url.length > 0 && this.urlParams.url[0].key && "query" === this.urlParams.url[0].key && (0, s.isValidURL)(this.urlParams.url[0].value) && (0, s.hasClass)(this.html, "show")) window.location.href = this.urlParams.url[0].value;
                    else {
                        (0, s.toggleClass)(this.html, "show");
                        var e = (0, s.hasClass)(this.html, "show");
                        this.toggleScroll(e), !e && this.launcherBtn && this.launcherBtn.focus(), t && t.detail && (this.launcherBtn = t.detail.launcherBtn), this.isTabletMin && (this.accordionCloseItems(), this.showCurrentlyViewingElement());
                        var i = void 0,
                            n = void 0;
                        t && t.detail.launcherBtn ? (i = this.launcherBtn.innerText.trim(), n = this.launcherBtn.getAttribute("href")) : t && t.target && document.body !== t.target && (i = t.currentTarget.innerText && t.currentTarget.innerText.trim(), n = t.target.getAttribute("href")), this.setAnalytics("click", e ? "open" : "close", {
                            event: e ? "global_open_click" : "global_close_click",
                            module_name: "globalSelectorV2",
                            link_text: i || (e ? "open" : "close"),
                            link_url: n || void 0
                        })
                    }
                }, t.prototype.toggleScroll = function(t) {
                    t ? ((0, s.addClass)(this.bodyScroll, "_prevent-scroll"), this.setKeyTrap()) : ((0, s.removeClass)(this.bodyScroll, "_prevent-scroll"), this.removeKeyTrap())
                }, t.prototype.setKeyTrap = function() {
                    0 === (0, s.qsa)(".trap-element", this.html).length && this.html.insertAdjacentHTML("beforeend", '<div class="trap-element" tabindex="0"></div>'), this.tabTrap = new n.default({
                        html: this.html
                    })
                }, t.prototype.removeKeyTrap = function() {
                    this.tabTrap && this.tabTrap.removeTrapFocus()
                }, t.prototype.stripTrailingSlash = function(t) {
                    return t.replace(/\/$/, "").toLowerCase()
                }, t.prototype.locationWeight = function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        i = this.location,
                        s = i.host,
                        n = i.pathname,
                        a = this.stripTrailingSlash(s + n),
                        o = this.stripTrailingSlash(s);
                    return a === t && e ? 4 : a === t ? 3 : o === t && e ? 2 : o === t ? 1 : 0
                }, t.prototype.currentlyViewingObject = function(t, e, i, s) {
                    var n = i.Host,
                        a = 0;
                    if (t.indexOf(n) >= 0) {
                        var o = s,
                            l = this.stripTrailingSlash(t);
                        return o.global && (o.site = {}, o.site.IsCountrySite = !0), a = this.locationWeight(l, o.site && o.site.IsCountrySite), o.weight = a, e.weight > a ? e : o
                    }
                    return e
                }, t.prototype.getCurrentlyViewing = function() {
                    var t = this,
                        e = /(http(s)?:\/\/)?/g,
                        i = this.GSData,
                        n = i.Regions,
                        a = i.Host,
                        o = {
                            GlobalTitle: this.GSData.GlobalTitle,
                            GlobalUrl: this.GSData.GlobalUrlLink,
                            GlobalUrlTarget: this.GSData.GlobalUrlTarget
                        },
                        l = {},
                        r = {
                            Host: a
                        };
                    return l = this.currentlyViewingObject(o.GlobalUrl.replace(e, ""), l, r, {
                        global: o
                    }), (0, s.forEach)(n, (function(i) {
                        (0, s.forEach)(i.Countries, (function(n) {
                            (0, s.forEach)(n.Sites, (function(s) {
                                var a = s.LinkUrl ? s.LinkUrl.split("?")[0].replace(e, "").toLowerCase() : "";
                                l = t.currentlyViewingObject(a, l, r, {
                                    region: i.RegionId,
                                    country: n.CountryId,
                                    site: s
                                })
                            }))
                        }))
                    })), l
                }, t.prototype.showCurrentlyViewingElement = function() {
                    var t = this,
                        e = Object.keys(this.currentViewObj).length,
                        i = this.currentViewObj,
                        n = i.country,
                        a = i.region,
                        o = i.global;
                    if (e && o)(0, s.addClass)(this.globalBtn, "font--semibold"), (0, s.removeClass)(this.globalBtn, "font--regular");
                    else if (e && a) {
                        var l = (0, s.qsa)("." + this.GSClass + '--country[data-country="' + n + '"]', this.html);
                        this.toggleAccordionState((0, s.qs)("." + this.GSClass + '--headerBtn[data-region="' + a + '"]', this.html)), (0, s.forEach)(l, (function(e) {
                            t.getCountryData(e)
                        }))
                    }
                }, t.prototype.getCurrentlyViewingSite = function() {
                    var t = this,
                        e = (0, s.qsa)("." + this.GSClass + "--currentlyText", this.html),
                        i = this.currentViewObj.site,
                        n = e.length > 0 ? null : '\n    <span class="' + this.GSClass + '--currentlyText font--semibold">\n      ' + (0, s.sanitizeHTML)(this.GSData.TitleConfig.CurrentViewTitle) + "\n    </span>";
                    if (i && n) {
                        var a = (0, s.qsa)("." + this.GSClass + '--siteWrapper[data-site="' + i.SiteId + '"]', this.html);
                        (0, s.forEach)(a, (function(e) {
                            e.insertAdjacentHTML("afterbegin", n), (0, s.addClass)(e, t.GSClass + "-currentSite")
                        }))
                    }
                }, t.prototype.getCountryData = function(t) {
                    var e = t,
                        i = e.dataset,
                        s = i.country,
                        n = i.region,
                        a = this.GSData.Regions.reduce((function(t, e) {
                            return e.RegionId === n ? e.Countries : t
                        }), {}).reduce((function(t, e) {
                            return e.CountryId === s ? e : t
                        }), {}),
                        o = this.orderSitesByBrand(a);
                    this.panelTitle = a.Title;
                    var l = this.GSMarkup.createSitesLayout(o, n);
                    this.addSitesToSections(e, l), this.toggleCountrySelectedClass(s, n)
                }, t.prototype.toggleCountrySelectedClass = function(t, e) {
                    var i = (0, s.qsa)("." + this.GSClass + '--country[data-region="' + e + '"]', this.html);
                    (0, s.forEach)(i, (function(e) {
                        var i = e.dataset.country === t;
                        (0, s.addClass)(e, i ? "font--semibold" : "font--regular"), (0, s.removeClass)(e, i ? "font--regular" : "font--semibold")
                    }))
                }, t.prototype.orderSitesByBrand = function(t) {
                    return t.Sites.reduce((function(t, e) {
                        var i = t.findIndex((function(t) {
                                return t.BrandTitle === e.BrandTitle
                            })),
                            s = t;
                        return i >= 0 ? s[i].Sites = [].concat(s[i].Sites, e) : s = [].concat(t, [{
                            Sites: [].concat(e),
                            BrandTitle: e.BrandTitle,
                            BrandIndex: e.BrandIndex
                        }]), s
                    }), []).sort((function(t, e) {
                        return t.BrandIndex - e.BrandIndex
                    }))
                }, t.prototype.addCountriesToMobileSection = function(t) {
                    var e = (0, s.qs)("." + this.GSClass + "--itemCountries", t).innerHTML,
                        i = (0, s.qs)("." + this.GSClass + "--sectionData .container", this.countryListWapper),
                        n = (0, s.closest)(t, "." + this.GSClass + "--section"),
                        a = (0, s.qs)("." + this.GSClass + "--mobileTitle", this.countryListWapper);
                    i.innerHTML = e, this.handleCountryEvents(this.countryListWapper), this.mobileNavigation(n.dataset.section, this.isRtl ? "slideInLeft" : "slideInRight"), this.updateMobileNavTitle(this.countryListWapper), this.bodyScroll.offsetWidth < 768 && (a.setAttribute("tabindex", 0), a.focus(), a.setAttribute("tabindex", -1))
                }, t.prototype.addSitesToSections = function(t, e) {
                    var i = (0, s.qs)("." + this.GSClass + "--siteList", this.html),
                        n = (0, s.qs)("." + this.GSClass + "--sectionData .container", i),
                        a = (0, s.qs)("." + this.GSClass + '--itemContent[data-region="' + t.dataset.region + '"]'),
                        o = (0, s.qs)("." + this.GSClass + "--itemSites", a),
                        l = (0, s.qs)("." + this.GSClass + "--mobileTitle", i);
                    o.innerHTML = e, n.innerHTML = e, this.mobileNavigation(2, this.isRtl ? "slideInLeft" : "slideInRight"), this.updateMobileNavTitle(i), this.getCurrentlyViewingSite(), this.bodyScroll.offsetWidth < 768 ? (l.setAttribute("tabindex", 0), l.focus(), l.setAttribute("tabindex", -1)) : (o.setAttribute("tabindex", 0), o.focus(), o.setAttribute("tabindex", -1)), this.handleSitesEvents(this.html)
                }, t.prototype.toggleAccordionState = function(t, e) {
                    var i = (0, s.closest)(t, "." + this.GSClass + "--item"),
                        n = (0, s.qs)("." + this.GSClass + "--itemContent", i),
                        a = (0, s.qs)("." + this.GSClass + "--itemTitle", t),
                        o = (0, s.hasClass)(i, "openItem");
                    (0, s.toggleAttribute)(n, "hidden");
                    var l = t.getAttribute("aria-expanded");
                    t.setAttribute("aria-expanded", "true" === l ? "false" : "true"), this.panelTitle = a.innerHTML, this.addCountriesToMobileSection(i), o && (this.mobileBackToStart(), this.clearContent(i)), this.accordionCloseItems(i), (0, s.toggleClass)(i, "openItem"), (0, s.addClass)(t, o ? "font--regular" : "font--semibold"), (0, s.removeClass)(t, o ? "font--semibold" : "font--regular"), e && e(o)
                }, t.prototype.accordionCloseItems = function(t) {
                    var e = this,
                        i = (0, s.qsa)(".openItem", this.html);
                    (0, s.forEach)(i, (function(i) {
                        if (i !== t) {
                            var n = (0, s.qs)("." + e.GSClass + "--headerBtn", i);
                            (0, s.removeClass)(i, "openItem"), (0, s.qs)("." + e.GSClass + "--itemContent", i).setAttribute("hidden", !0), n.setAttribute("aria-expanded", "false"), (0, s.addClass)(n, "font--regular"), (0, s.removeClass)(n, "font--semibold"), e.clearContent(i)
                        }
                    }))
                }, t.prototype.clearContent = function(t) {
                    (0, s.qs)("." + this.GSClass + "--itemSites", t).innerHTML = "", this.clearCountry(t)
                }, t.prototype.clearCountry = function(t) {
                    var e = (0, s.qs)("." + this.GSClass + "--country.font--semibold", t);
                    e && ((0, s.removeClass)(e, "font--semibold"), (0, s.addClass)(e, "font--regular"))
                }, t.prototype.mobileNavigation = function(t, e) {
                    (0, s.addAnimation)(this.sections[t], e), (0, s.addClass)(this.sections[1 !== t ? t - 1 : 0], "mobileHide"), (0, s.removeClass)(this.sections[t], "mobileHide")
                }, t.prototype.mobileBackButton = function(t) {
                    if (!this.isTabletMin) {
                        var e = t.target,
                            i = (0, s.closest)(e, "." + this.GSClass + "--section").dataset.section,
                            n = (0, s.qs)("." + this.GSClass + "--mobileTitle", this.sections[i - 2]);
                        (0, s.addAnimation)(this.sections[i - 2], this.isRtl ? "slideInRight" : "slideInLeft"), (0, s.removeClass)(this.sections[1 !== i ? i - 2 : 0], "mobileHide"), (0, s.addClass)(this.sections[i - 1], "mobileHide"), 2 !== i && "2" !== i || this.accordionCloseItems(), this.clearCountry(this.countryListWapper), this.bodyScroll.offsetWidth < 768 && n && (n.setAttribute("tabindex", 0), n.focus(), n.setAttribute("tabindex", -1))
                    }
                }, t.prototype.mobileBackToStart = function() {
                    (0, s.forEach)(this.sections, (function(t) {
                        (0, s.addClass)(t, "mobileHide")
                    })), (0, s.removeClass)(this.sections[0], "mobileHide")
                }, t.prototype.updateMobileNavTitle = function(t) {
                    (0, s.qs)("." + this.GSClass + "--navTitle", t).innerHTML = this.panelTitle
                }, t.prototype.setAnalytics = function(t, e, i) {
                    var s = e.trim(),
                        n = {
                            event: "trackEvent",
                            category: "global selector",
                            action: t,
                            label: s
                        };
                    this.analytics.pushCustomData(n, "Global selector - " + t + " - " + s), this.analytics.pushCustomData(i, "Global selector - " + t + " - " + s)
                }, t
            }();
            e.default = r
        },
        606: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var s = i(94);

            function n(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
            }
            var a = function() {
                function t() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    n(this, t), this.GSClass = e.GSClass || "globalSelectorV2"
                }
                return t.prototype.createGlobalBtn = function(t) {
                    return '<div class="' + this.GSClass + '--globalItem">\n      <div class="container">\n        <a href="' + t.GlobalUrl + '" target="' + t.GlobalUrlTarget + '" class="' + this.GSClass + '--globalBtn font--regular" data-region="Gobal">\n          ' + (0, s.sanitizeHTML)(t.GlobalTitle) + '\n          <i class="icon-dropdown-arrow"></i>\n        </a>\n      </div>\n    </div>'
                }, t.prototype.mobileTitlePanel = function(t, e) {
                    return '\n      <div class="' + this.GSClass + '--mobileTitle">\n        <button class="' + this.GSClass + '--backBtn" aria-label="' + e.stringBackButtonText + '">\n          <span class="icon-dropdown-arrow"></span>\n          <span class="visibility-hidden">' + e.stringBackButtonText + '</span>\n        </button>\n        <div class="' + this.GSClass + "--navTitle " + t + '"></div>\n      </div>'
                }, t.prototype.createCountryList = function(t) {
                    var e = this;
                    return "\n      " + t.Countries.map((function(i) {
                        return i.Title ? '<li class="' + e.GSClass + '--countryItem">\n          <button class="' + e.GSClass + '--country font--regular" data-country="' + (0, s.sanitizeHTML)(i.CountryId) + '" data-region="' + (0, s.sanitizeHTML)(t.RegionId) + '">\n          ' + (0, s.sanitizeHTML)(i.Title) + "\n          </button>\n        </li>" : ""
                    })).join("")
                }, t.prototype.createSitesLayout = function(t, e) {
                    var i = this,
                        n = "" + t.map((function(t) {
                            return '<div class="' + i.GSClass + '--countryBrand">\n        <p class="' + i.GSClass + '--brandTitle text-small">' + (0, s.sanitizeHTML)(t.BrandTitle) + '</p>\n        <div class="' + i.GSClass + '--brandSites">\n          ' + t.Sites.map((function(t) {
                                return t.LinkUrl && t.Title ? '<div class="' + i.GSClass + '--siteWrapper" data-site="' + (0, s.sanitizeHTML)(t.SiteId) + '">\n                <a href="' + t.LinkUrl + '" target="' + t.UrlTarget + '" class="' + i.GSClass + '--siteLink font--bold" data-site="' + (0, s.sanitizeHTML)(t.SiteId) + '" data-region="' + (0, s.sanitizeHTML)(e) + '">\n                  ' + (0, s.sanitizeHTML)(t.Title) + "\n                </a>\n              </div>" : ""
                            })).join("") + "\n        </div>\n      </div>"
                        })).join("");
                    return '<div class="' + this.GSClass + '--countryBrandsWrapper">' + n + "</div>"
                }, t.prototype.createRegionMarkup = function(t) {
                    var e = this;
                    return t.map((function(t) {
                        return '<div class="' + e.GSClass + '--item">\n        <div class="container">\n          <div class="' + e.GSClass + '--itemHeader">\n            <button\n              id="GS-header-' + (0, s.sanitizeHTML)(t.RegionId) + '"\n              class="' + e.GSClass + '--headerBtn font--regular"\n              data-region="' + (0, s.sanitizeHTML)(t.RegionId) + '"\n              aria-controls="' + (0, s.sanitizeHTML)(t.RegionId) + '"\n              aria-expanded="false"\n              >\n              <span class="' + e.GSClass + '--itemTitle">\n                ' + (0, s.sanitizeHTML)(t.Title) + '\n              </span>\n              <i class="icon-dropdown-arrow"></i>\n            </button>\n          </div>\n          <div class="' + e.GSClass + '--itemContent" hidden data-region="' + (0, s.sanitizeHTML)(t.RegionId) + '" id="' + (0, s.sanitizeHTML)(t.RegionId) + '">\n            <ul class="' + e.GSClass + "--itemCountries " + (t.Countries.length > 7 ? "splitColumns" : "singleColumn") + '">\n              ' + e.createCountryList(t) + '\n            </ul>\n            <div class="' + e.GSClass + '--itemSites"></div>\n          </div>\n        </div>\n      </div>'
                    }))
                }, t.prototype.createMarkup = function(t, e, i) {
                    return '\n      <div class="' + this.GSClass + '--header">\n        <div class="container">\n          <div class="' + this.GSClass + '--navLogo">\n            <img alt="' + e.stringAltLogo + '" src="' + e.stringLogo + '" class="">\n          </div>\n          <button class="' + this.GSClass + '--navClose" aria-label="' + e.stringCloseButtonText + '">\n            <i class="icon-close-light"></i>\n            <span class="visibility-hidden">' + e.stringCloseButtonText + '</span>\n          </button>\n        </div>\n      </div>\n\n      <div class="' + this.GSClass + '--wrapper">\n\n        ' + this.createGlobalBtn(i) + '\n\n        <div class="' + this.GSClass + '--sections">\n          <div class="' + this.GSClass + "--section " + this.GSClass + '--regionList" data-section="1">\n            ' + this.createRegionMarkup(t).join("") + '\n          </div>\n          <div class="' + this.GSClass + "--section " + this.GSClass + '--countryList mobileHide" data-section="2">\n            ' + this.mobileTitlePanel("font--regular", e) + '\n            <div class="' + this.GSClass + '--sectionData">\n              <ul class="container"></ul>\n            </div>\n          </div>\n          <div class="' + this.GSClass + "--section " + this.GSClass + '--siteList mobileHide" data-section="3">\n            ' + this.mobileTitlePanel("font--semibold", e) + '\n            <div class="' + this.GSClass + '--sectionData">\n              <ul class="container"></ul>\n            </div>\n          </div>\n        </div>\n\n      </div>'
                }, t
            }();
            e.default = a
        }
    }
]);