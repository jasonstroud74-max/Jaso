(window.webpackJsonp = window.webpackJsonp || []).push([
    [28], {
        208: function(t, i, e) {
            "use strict";
            Object.defineProperty(i, "__esModule", {
                value: !0
            });
            var s, a = e(131),
                n = (s = a) && s.__esModule ? s : {
                    default: s
                },
                l = e(94);
            var c = function() {
                function t(i) {
                    ! function(t, i) {
                        if (!(t instanceof i)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = i, this.analytics = new n.default, this.ctaEL = (0, l.qs)(".button", this.html), this.isVariable = (0, l.hasClass)(this.html, "singleFeature-variable"), this.description = (0, l.qs)(".singleFeature--textField--description", this.html), this.description && (0, l.handleBrElements)(this.description), this.ctaEL && (this.data = {
                        event: "trackEvent",
                        category: window.exxonPageType + " page",
                        action: "click",
                        label: "cta",
                        pagePosition: this.isVariable ? "variable single feature" : "single feature",
                        linkUrl: this.ctaEL.getAttribute("href"),
                        linkText: this.ctaEL.innerText
                    }, (0, l.$on)(this.ctaEL, "click", this.setAnalytics.bind(this)))
                }
                return t.prototype.setAnalytics = function() {
                    this.analytics.pushCustomData(this.data, "single feature")
                }, t
            }();
            i.default = c
        }
    }
]);