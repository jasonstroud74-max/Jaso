(window.webpackJsonp = window.webpackJsonp || []).push([
    [81], {
        179: function(t, i, s) {
            "use strict";
            Object.defineProperty(i, "__esModule", {
                value: !0
            });
            var e = l(s(594)),
                n = s(94),
                a = l(s(131));

            function l(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            var o = function() {
                function t(i) {
                    var s = this;
                    ! function(t, i) {
                        if (!(t instanceof i)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = i, this.msnry = {}, this.msnryHtml = (0, n.qs)(".keytopics", this.html), this.links = (0, n.qsa)(".keytopics--item .keytopics--link", this.html), this.infos = (0, n.qsa)(".info", this.html), this.analytics = new a.default, this.htmlTag = (0, n.qs)("html"), this.rtlClass = "i18n-rtl", window.addEventListener("load", (function() {
                        s.gridInit()
                    })), (0, n.forEach)(this.links, (function(t) {
                        (0, n.$on)(t, "click", s.setAnalytics.bind(s))
                    })), (0, n.forEach)(this.infos, (function(t) {
                        var i = (0, n.qs)("a", t);
                        (0, n.$on)(i, "click", s.handleClickTag.bind(s, t.parentNode))
                    }))
                }
                return t.prototype.setAnalytics = function(t) {
                    var i = t.target,
                        s = i.getAttribute("data-analytics") ? i : (0, n.closest)(i, "[data-analytics]"),
                        e = JSON.parse(s.dataset.analytics) || {};
                    this.analytics.pushCustomData(e, "key topics item"), this.handleAnalyticsGA4(e)
                }, t.prototype.handleClickTag = function(t) {
                    var i = (0, n.qs)(".keytopics--link", t).dataset.analytics,
                        s = JSON.parse(i) || {};
                    this.handleAnalyticsGA4(s)
                }, t.prototype.handleAnalyticsGA4 = function(t) {
                    var i = t.title,
                        s = t.publishDate,
                        e = t.contentType,
                        a = t.multimediaType,
                        l = t.linkUrl,
                        o = s ? s.substring(0, s.indexOf(" ")) : "",
                        c = o.split("/")[2] + "-" + o.split("/")[0].padStart(2, "0") + "-" + o.split("/")[1].padStart(2, "0"),
                        r = {
                            event: "key_topic_card_click",
                            module_name: "keytopics",
                            section_header: document.title,
                            link_text: i,
                            link_url: l,
                            link_type: (0, n.getLinkType)(l),
                            article_name: i,
                            published_date: s ? c : void 0,
                            category_name: l.slice(1, l.slice(1).indexOf("/") + 1),
                            content_type: e,
                            multimedia_type: a || void 0
                        };
                    this.analytics.pushCustomData(r, "key_topic_card_click GA4")
                }, t.prototype.gridInit = function() {
                    (0, n.removeClass)(this.msnryHtml, "keytopics-loading"), this.msnry = new e.default(this.msnryHtml, {
                        columnWidth: ".keytopics--sizer",
                        itemSelector: ".keytopics--item",
                        percentPosition: !0,
                        horizontalOrder: !0,
                        gutter: ".gutter--sizer",
                        isOriginLeft: !(0, n.hasClass)(this.htmlTag, this.rtlClass)
                    }), this.msnry.layout()
                }, t
            }();
            i.default = o
        }
    }
]);