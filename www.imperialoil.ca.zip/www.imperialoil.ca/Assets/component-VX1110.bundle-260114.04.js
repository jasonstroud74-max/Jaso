(window.webpackJsonp = window.webpackJsonp || []).push([
    [10, 32], {
        132: function(t, e, s) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var o = s(94);
            var i = ["a[href]:not([disabled])", "button:not([disabled])", "textarea:not([disabled])", 'input[type="text"]:not([disabled])', 'input[type="radio"]:not([disabled])', 'input[type="checkbox"]:not([disabled])', 'select:not([disabled]):not([tabindex="-1"])', '[tabindex]:not([tabindex="-1"])'],
                a = function() {
                    function t(e) {
                        var s = e.html,
                            a = void 0 === s ? document.body : s,
                            n = e.reloaded,
                            l = void 0 !== n && n,
                            c = e.selectorsList,
                            h = void 0 === c ? i : c,
                            r = e.defaultFocus,
                            u = e.ignoreElement;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.html = a, this.defaultFocus = r, this.body = (0, o.qs)("body"), this.KEYCODE_TAB = 9, this.selectorsList = h.join(), this.ignoreElement = u, this.hiddenElements = [], this.setFocusableElements(), this.trapFocusReference = this.trapFocus.bind(this), l || (this.defaultFocus ? this.defaultFocus.focus() : this.firstFocusableEl.focus()), (0, o.$on)(window, "keydown", this.trapFocusReference)
                    }
                    return t.prototype.trapFocus = function(t) {
                        ("Tab" === t.key || t.keyCode === this.KEYCODE_TAB) && (t.shiftKey ? document.activeElement === this.firstFocusableEl && (this.lastFocusableEl.focus(), t.preventDefault()) : document.activeElement === this.lastFocusableEl && (this.firstFocusableEl.focus(), t.preventDefault()))
                    }, t.prototype.setFocusableElements = function() {
                        var t = this;
                        this.focusableElements = (0, o.qsa)(this.selectorsList, this.html), this.ignoreElement && (this.focusableElements = Array.from(this.focusableElements).filter((function(e) {
                            return !(0, o.hasClass)(e, t.ignoreElement)
                        })));
                        var e = this.focusableElements;
                        this.firstFocusableEl = e[0], this.lastFocusableEl = this.focusableElements[this.focusableElements.length - 1], this.setMobileFocusLoop()
                    }, t.prototype.removeTrapFocus = function() {
                        (0, o.forEach)(this.hiddenElements, (function(t) {
                            t.removeAttribute("aria-hidden"), t.removeAttribute("inert")
                        })), (0, o.$off)(window, "keydown", this.trapFocusReference)
                    }, t.prototype.setMobileFocusLoop = function() {
                        for (var t = this.html; t !== this.body;) {
                            for (var e = t.parentNode.childNodes, s = 0; s < e.length; s += 1) {
                                var i = e[s];
                                i && i.classList && (0, o.hasClass)(i, "skip-content") || i.id && "onetrust-consent-sdk" === i.id || i !== t && i.setAttribute && (i.setAttribute("inert", ""), i.setAttribute("aria-hidden", "true"), this.hiddenElements = [].concat(this.hiddenElements, [i]))
                            }
                            t = t.parentNode
                        }
                    }, t
                }();
            e.default = a
        },
        193: function(t, e, s) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var o = s(94),
                i = n(s(132)),
                a = n(s(131));

            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            var l = function() {
                function t(e) {
                    var s = this;
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = e, this.titleDocument = document.title, this.className = "searchBar", this.close = (0, o.qs)(".searchBar--close", e), this.overlay = (0, o.qs)(".searchBar--overlay", e), this.modal = (0, o.qs)(".searchBar--wrapper", this.html), this.Analytics = new a.default, this.Analytics.setData({
                        event: "trackEvent",
                        category: "search"
                    }), (0, o.$on)(this.close, "click", this.closePopUp.bind(this)), (0, o.$on)(this.overlay, "click", this.closeOverlay.bind(this)), (0, o.$on)(this.overlay, "touchstart", this.closeOverlay.bind(this)), (0, o.$on)(window, "keydown", this.escClose.bind(this)), (0, o.$on)(window, "resize", this.popUpPosition.bind(this)), (0, o.$on)(document, "openSearch", (function(t) {
                        t.detail && t.detail.close ? s.closePopUp() : s.toggleState()
                    }))
                }
                return t.prototype.popUpPosition = function() {
                    var t = (0, o.qs)(".mainNav");
                    t && (this.modal.style.top = t.offsetTop + t.offsetHeight - 1 + "px")
                }, t.prototype.toggleState = function() {
                    this.popUpPosition(), (0, o.toggleClass)(this.html, "open");
                    var t = (0, o.hasClass)(this.html, "open");
                    this.Analytics.pushDataWithParameters({
                        label: t ? "open" : "close",
                        action: "search - top nav"
                    }), this.Analytics.pushCustomData({
                        event: t ? "search_open" : "search_close",
                        module_name: this.className,
                        section_header: this.titleDocument
                    }, t ? "search_open GA4" : "search_close GA4"), t && this.setTabTrap()
                }, t.prototype.setTabTrap = function() {
                    var t = this;
                    this.tabTrap = new i.default({
                        html: this.html
                    }), (0, o.$on)(document, "reloadItems", (function(e) {
                        e.stopPropagation(), e.detail && e.detail.reloaded && (t.tabTrap = {}, t.tabTrap = new i.default({
                            html: t.html,
                            reloaded: !0
                        }))
                    }))
                }, t.prototype.escClose = function(t) {
                    27 === t.keyCode && (0, o.hasClass)(this.html, "open") && (this.closePopUp(), (0, o.$off)(window, "keydown", this.escClose.bind(this)))
                }, t.prototype.closePopUp = function() {
                    if ((0, o.hasClass)(this.html, "open")) {
                        (0, o.removeClass)(this.html, "open");
                        var t = (0, o.hasClass)(this.html, "open");
                        this.Analytics.pushDataWithParameters({
                            label: t ? "open" : "close",
                            action: "search - top nav"
                        }), this.Analytics.pushCustomData({
                            event: t ? "search_open" : "search_close",
                            module_name: this.className,
                            section_header: this.titleDocument
                        }, t ? "search_open GA4" : "search_close GA4"), document.dispatchEvent(new CustomEvent("openHomePopUp", {
                            detail: {
                                close: !0
                            }
                        })), this.tabTrap.removeTrapFocus()
                    }
                }, t.prototype.closeOverlay = function() {
                    this.closePopUp()
                }, t
            }();
            e.default = l
        }
    }
]);