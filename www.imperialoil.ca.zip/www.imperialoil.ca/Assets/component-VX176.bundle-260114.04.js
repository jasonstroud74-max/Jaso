(window.webpackJsonp = window.webpackJsonp || []).push([
    [80], {
        178: function(t, n, e) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var i, a = e(94),
                o = e(131),
                r = (i = o) && i.__esModule ? i : {
                    default: i
                };
            var c = function() {
                function t(n) {
                    var e = this;
                    ! function(t, n) {
                        if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = n;
                    var i = this.html.dataset,
                        o = i.urlservice,
                        c = i.contextid,
                        s = i.itemid,
                        l = i.language;
                    this.container = (0, a.qs)(".trending--content", this.html), this.title = (0, a.qs)(".trending--title", this.html), this.urlService = o + "?itemid=" + s + "&contextid=" + c + "&language=" + l, this.analytics = new r.default, window.addEventListener("load", (function() {
                        e.getTrendings()
                    }))
                }
                return t.prototype.getTrendings = function() {
                    var t = this;
                    (0, a.xhrRequest)("GET", this.urlService, {}, "text/html").then((function(n) {
                        t.container.innerHTML = n, t.trendingLinks = (0, a.qsa)(".trending--item .link-black", t.container), t.anchorsNotTrending = (0, a.qsa)("a:not(.link-black)", t.container), (0, a.forEach)(t.trendingLinks, (function(n) {
                            (0, a.$on)(n, "click", t.setAnalytics.bind(t))
                        })), (0, a.forEach)(t.anchorsNotTrending, (function(n) {
                            (0, a.$on)(n, "click", t.setAnalytics.bind(t))
                        })), window.AppInstance.loadItems().then(console.log("reload"))
                    })).catch((function(t) {
                        console.error(t)
                    }))
                }, t.prototype.setAnalytics = function(t) {
                    var n = t.target,
                        e = "I" === n.nodeName ? n.parentNode : n,
                        i = e.getAttribute("href"),
                        o = {
                            event: "trackEvent",
                            category: window.exxonPageType + " page",
                            action: "click",
                            label: "trending",
                            linkUrl: i,
                            linkText: e.innerText
                        },
                        r = {
                            event: "trending_click",
                            module_name: "trending",
                            section_header: this.title.textContent.trim(),
                            link_text: e.innerText || e.ariaLabel,
                            link_url: i,
                            link_type: (0, a.getLinkType)(i)
                        };
                    this.analytics.pushCustomData(o, "trending"), this.analytics.pushCustomData(r, "trending_click GA4")
                }, t
            }();
            n.default = c
        }
    }
]);