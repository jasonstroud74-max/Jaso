(window.webpackJsonp = window.webpackJsonp || []).push([
    [62], {
        163: function(t, n, a) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var i, o = a(131),
                e = (i = o) && i.__esModule ? i : {
                    default: i
                },
                c = a(94);
            var s = function() {
                function t(n) {
                    var a = this;
                    ! function(t, n) {
                        if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = n, this.linksList = (0, c.qsa)(".footer--link", this.html), this.socialLinks = (0, c.qsa)(".footer--socialIcon", this.html), this.oneTrustModal = (0, c.qsa)(".optanon-toggle-display", this.html), this.anchors = (0, c.qsa)("a", this.html), this.analytics = new e.default, (0, c.forEach)(this.linksList, (function(t) {
                        (0, c.$on)(t, "click", a.analyticsLink.bind(a))
                    })), (0, c.forEach)(this.socialLinks, (function(t) {
                        (0, c.$on)(t, "click", a.analyticsSocial.bind(a))
                    })), (0, c.forEach)(this.anchors, (function(t) {
                        (0, c.$on)(t, "click", a.handleAnalyticsNavClick.bind(a))
                    })), (0, c.forEach)(this.oneTrustModal, (function(t) {
                        (0, c.$on)(t, "keydown", (function(t) {
                            13 === t.keyCode && t.target.click()
                        }))
                    }))
                }
                return t.prototype.analyticsLink = function(t) {
                    var n = {
                        event: "trackEvent",
                        category: "navigation",
                        action: "click - footer nav",
                        label: t.target.innerText
                    };
                    this.analytics.pushCustomData(n, "click - footer nav " + t.target.innerText)
                }, t.prototype.analyticsSocial = function(t) {
                    var n = t.target.getAttribute("alt") || "Social Icon",
                        a = {
                            event: "trackEvent",
                            category: "navigation",
                            action: "click - social sharing",
                            label: n,
                            pagePosition: "footer"
                        };
                    this.analytics.pushCustomData(a, "click - footer nav social - " + n)
                }, t.prototype.handleAnalyticsNavClick = function(t) {
                    var n = t.target.href || t.target.parentNode.href,
                        a = {
                            event: "nav_click",
                            module_name: "footer",
                            link_text: t.target.innerText || t.target.alt,
                            link_url: n,
                            link_type: (0, c.getLinkType)(n)
                        };
                    this.analytics.pushCustomData(a, "nav_click GA4")
                }, t
            }();
            n.default = s
        }
    }
]);