(window.webpackJsonp = window.webpackJsonp || []).push([
    [83], {
        180: function(n, t, e) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = e(94);
            var o = function() {
                function n(t) {
                    var e = this;
                    ! function(n, t) {
                        if (!(n instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, n), this.html = t, this.select = (0, a.qs)("select", this.html), (0, a.$on)(this.select, "change", (function(n) {
                        e.changeLanguage(n.target.value)
                    }))
                }
                return n.prototype.changeLanguage = function(n) {
                    window.location.href = "" + n
                }, n
            }();
            t.default = o
        }
    }
]);