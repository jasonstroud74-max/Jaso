(window.webpackJsonp = window.webpackJsonp || []).push([
    [78], {
        176: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var a = i(94);
            var r = function() {
                function t(e) {
                    var i = this;
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = e;
                    var r = (0, a.getUrlQueryParams)().print;
                    this.isPrintUrl = !!r, this.matchMedia = {
                        desktop: {
                            media: window.matchMedia("(min-width: 1024px)"),
                            urlImage: this.html.dataset.desktop,
                            isActive: !1
                        },
                        tablet: {
                            media: window.matchMedia("(min-width: 768px) and (max-width: 1023px)"),
                            urlImage: this.html.dataset.tablet,
                            isActive: !1
                        },
                        mobile: {
                            media: window.matchMedia("(min-width: 0) and (max-width: 767px)"),
                            urlImage: this.html.dataset.mobile,
                            isActive: !1
                        },
                        print: {
                            media: window.matchMedia("print"),
                            urlImage: this.html.dataset.tablet,
                            isActive: !0
                        }
                    }, this.handleScroll = this.handleScroll.bind(this), this.handleYoutubeAlt(), this.isPrintUrl ? this.loadLazyImage("print") : "true" === this.html.dataset.scroll ? this.shouldImgBeVisible(200) ? this.loopMediaMatches() : window.addEventListener("scroll", this.handleScroll) : window.addEventListener("load", (function() {
                        i.loopMediaMatches()
                    }))
                }
                return t.prototype.handleYoutubeAlt = function() {
                    var t = "img" === this.html.getAttribute("role"),
                        e = this.matchMedia.mobile.urlImage && this.matchMedia.mobile.urlImage.includes("youtube.com");
                    if (t && e) {
                        var i = this.findRelatedModalId();
                        i && this.setAriaLabelFromModal(i)
                    }
                }, t.prototype.findRelatedModalId = function() {
                    for (var t = this.html.parentElement; t;) {
                        if (t.dataset.modalid) return t.dataset.modalid;
                        t = t.parentElement
                    }
                    return null
                }, t.prototype.setAriaLabelFromModal = function(e) {
                    var i = (0, a.qs)("#" + e);
                    if (i) {
                        var r = (0, a.qs)("iframe", i);
                        if (r) {
                            var l = t.getIframeTitle(r);
                            l ? this.setAriaLabel(l) : this.setupTitleObserver(r)
                        }
                    }
                }, t.getIframeTitle = function(t) {
                    return t.getAttribute("title") || t.getAttribute("aria-label") || ""
                }, t.prototype.setAriaLabel = function(t) {
                    t && t.trim() && this.html.setAttribute("aria-label", t.trim())
                }, t.prototype.setupTitleObserver = function(e) {
                    var i = this,
                        a = new MutationObserver((function(r) {
                            r.some((function(r) {
                                if (t.isTitleMutation(r)) {
                                    var l = t.getIframeTitle(e);
                                    if (l) return i.setAriaLabel(l), a.disconnect(), !0
                                }
                                return !1
                            }))
                        }));
                    a.observe(e, {
                        attributes: !0,
                        attributeFilter: ["title", "aria-label"],
                        subtree: !1
                    })
                }, t.isTitleMutation = function(t) {
                    return "attributes" === t.type && ("title" === t.attributeName || "aria-label" === t.attributeName)
                }, t.prototype.handleScroll = function() {
                    this.shouldImgBeVisible() && this.loopMediaMatches()
                }, t.prototype.shouldImgBeVisible = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        e = this.html,
                        i = t + window.innerHeight,
                        a = e.getBoundingClientRect().top;
                    return a < i
                }, t.prototype.loopMediaMatches = function() {
                    for (var t = Object.keys(this.matchMedia), e = 0; e < t.length; e += 1) {
                        var i = this.matchMedia[t[e]].media;
                        this.checkForActiveMedia(i)
                    }
                }, t.prototype.checkForActiveMedia = function(t) {
                    for (var e = Object.keys(this.matchMedia), i = 0; i < e.length; i += 1) {
                        if (this.matchMedia[e[i]].isActive = this.matchMedia[e[i]].media.matches, t.media === this.matchMedia[e[i]].media.media && this.matchMedia[e[i]].isActive) {
                            this.loadLazyImage(e[i]);
                            break
                        }
                    }
                }, t.prototype.loadLazyImage = function(t) {
                    var e = this,
                        i = this.matchMedia[t].urlImage;
                    this.matchMedia[t].image = new Image, this.matchMedia[t].image.src = i, this.matchMedia[t].image.onload = function() {
                        var i = "maxresdefault",
                            r = "sddefault",
                            l = "hqdefault";
                        if (e.matchMedia[t].image.src.includes(i) && 90 === e.matchMedia[t].image.height) e.loadLazyImage("tablet");
                        else {
                            if (e.matchMedia[t].image.src.includes(r) && 90 === e.matchMedia[t].image.height) return e.matchMedia.mobile.urlImage = e.matchMedia.tablet.urlImage.replace(r, l), void e.loadLazyImage("mobile");
                            (0, a.addClass)(e.html, "has-loaded"), e.html.style.backgroundImage = "url('" + e.matchMedia[t].image.src + "')", window.removeEventListener("scroll", e.handleScroll)
                        }
                    }
                }, t
            }();
            e.default = r
        }
    }
]);