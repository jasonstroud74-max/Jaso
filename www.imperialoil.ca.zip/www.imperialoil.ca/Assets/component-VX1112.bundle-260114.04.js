(window.webpackJsonp = window.webpackJsonp || []).push([
    [11], {
        194: function(e, t, a) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = a(94);
            var s = function() {
                function e(t) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this.html = t, this.pageSearch = JSON.parse(this.html.dataset.pagesearch.toLowerCase()), (0, n.$on)(this.html, "click", this.openSearch.bind(this)), this.arrow = (0, n.qs)(".searchBar--wrapper .arrow"), this.close = (0, n.qs)(".searchBar--wrapper .searchBar--close"), this.maxWidth = 1920, this.maximumGrid = !1;
                    var a = window.matchMedia("(min-width: " + this.maxWidth + "px)");
                    a.addListener(this.handleMediaQueryChange.bind(this)), this.handleMediaQueryChange(a)
                }
                return e.prototype.openSearch = function() {
                    var e = ".searchModule--search";
                    this.pageSearch ? e = ".main-content " + e : (document.dispatchEvent(new CustomEvent("openSearch")), (0, n.toggleClass)(this.html, "open"), document.dispatchEvent(new CustomEvent("openHomePopUp"))), (0, n.qs)(e) && (0, n.qs)(e).focus()
                }, e.prototype.handleMediaQueryChange = function(e) {
                    this.maximumGrid = e.matches
                }, e
            }();
            t.default = s
        }
    }
]);