(window.webpackJsonp = window.webpackJsonp || []).push([
    [0, 52], {
        139: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var s, o = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var i = arguments[e];
                        for (var s in i) Object.prototype.hasOwnProperty.call(i, s) && (t[s] = i[s])
                    }
                    return t
                },
                n = i(94),
                l = i(445),
                a = i(131),
                r = (s = a) && s.__esModule ? s : {
                    default: s
                };
            var h = function() {
                function t(e) {
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = e;
                    var i = this.html.dataset.moduleName;
                    this.blockNameForAppend = i ? "" + i : "cardCollection", this.blockName = i ? "." + i : ".cardCollection", this.container = (0, n.qs)(this.blockName + "--content", this.html, i), this.containerWidth = this.container.clientWidth, this.header = (0, n.qs)(this.blockName + "--header", this.html), this.list = (0, n.qs)(this.blockName + "--list", this.html), this.firstListWidth = this.list.clientWidth, this.listWidth = this.list.clientWidth, this.items = (0, n.qsa)(this.blockName + "--item", this.html), this.item = (0, n.qs)(this.blockName + "--item", this.html), this.itemWidth = (0, n.qs)(this.blockName + "--item", this.html).clientWidth, this.bullets = (0, n.qs)(this.blockName + "--bullets", this.html), this.arrows = (0, n.qsa)(this.blockName + "--arrows", this.html), this.scrollAmount = (0, n.qs)(this.blockName + "--scrollAmount", this.html), this.leftArrows = (0, n.qsa)(this.blockName + "--arrows .left-arrow", this.html), this.rightArrows = (0, n.qsa)(this.blockName + "--arrows .right-arrow", this.html), this.controls = (0, n.qs)(this.blockName + "--controls", this.html), this.blankItems = [], this.windowWidth = window.innerWidth, this.currentTotalBlocks = 0, this.totalItemsAdd = 0, this.maxItems = 10, this.bgRandom = this.html.dataset.bgrandom, this.analytics = new r.default, this.isRtl = "rtl" === document.querySelector("html").getAttribute("dir"), this.xDown = null, this.yDown = null, this.isAnimating = !1, this.initScript(), this.maxScrollLeft = this.container.scrollWidth - this.container.clientWidth, this.analyticsGA4Obj = {
                        event: "Article" === window.exxonPageType ? "article_carousel_scroll_click" : "carousel_scroll_click",
                        module_name: "carousel",
                        section_header: (0, n.getClosetSectionHeader)(this.html),
                        position_maximum: this.totalBlocks()
                    }, (0, n.$on)(window, "resize", this.handleResize.bind(this))
                }
                return t.prototype.handleResize = function() {
                    var t = this;
                    if (window.innerWidth !== this.windowWidth) {
                        if (this.windowWidth = window.innerWidth, this.handleTotalItemsOnScreen(), this.currentTotalBlocks === this.totalBlocks() && this.items.length <= this.totalItemsOnScreen) {
                            var e = (0, n.qsa)(this.blockName + "--bullet", this.html);
                            return void(0, n.forEach)(e, (function(e, i) {
                                (0, n.hasClass)(e, "active") && (t.blockNumb = i, t.activeBullets(), t.animateScroll(t.container.scrollLeft, t.itemWidth * t.totalItemsOnScreen * i, !0))
                            }))
                        }
                        this.removeBullets(), this.initScript(), this.maxScrollLeft = this.container.scrollWidth - this.container.clientWidth
                    }
                }, t.prototype.initScript = function() {
                    this.handleEvents(), this.removeBlankItems(), this.items.length > this.totalItemsOnScreen ? (this.addBullets(), this.handleItems(), this.manageArrowsVisibility(), (0, n.forEach)(this.arrows, (function(t) {
                        (0, n.removeClass)(t, "d-none-important")
                    }))) : (0, n.forEach)(this.arrows, (function(t) {
                        (0, n.addClass)(t, "d-none-important")
                    })), "true" === this.bgRandom && this.randomBackgroundPosition()
                }, t.prototype.removeBullets = function() {
                    var t = (0, n.qsa)(this.blockName + "--bullet", this.html),
                        e = (0, n.qsa)(this.blockName + "--bullet-wrapper", this.html);
                    (0, n.hasClass)(this.bullets, "tenUp") && (0, n.removeClass)(this.bullets, "tenUp"), (0, n.forEach)(t, (function(t) {
                        t.remove()
                    })), e.length && (0, n.forEach)(e, (function(t) {
                        t.remove()
                    }))
                }, t.prototype.handleTotalItemsOnScreen = function() {
                    window.innerWidth >= 1440 ? this.totalItemsOnScreen = 4 : window.innerWidth >= 1024 ? this.totalItemsOnScreen = 3 : window.innerWidth >= 768 ? this.totalItemsOnScreen = 2 : this.totalItemsOnScreen = 1
                }, t.prototype.handleEvents = function() {
                    var t = this;
                    this.handleTotalItemsOnScreen(), (0, n.hasClass)(this.html, "fourUp") && window.innerWidth >= 1024 && (this.totalItemsOnScreen = 4), ".highlight" === this.blockName && !(0, n.hasClass)(this.html, "fourUp") && window.innerWidth >= 1024 && (this.totalItemsOnScreen = 3), ".audioEFOneColumn--contentContainer" === this.blockName && window.innerWidth >= 1024 && (this.totalItemsOnScreen = 3), this.blockNumb = this.isRtl ? this.totalBlocks() - 1 : 0, (0, n.forEach)(this.leftArrows, (function(e) {
                        (0, n.$on)(e, "click", (function() {
                            t.scrollTo("left", "arrow")
                        }))
                    })), (0, n.forEach)(this.rightArrows, (function(e) {
                        (0, n.$on)(e, "click", (function() {
                            t.scrollTo("right", "arrow")
                        }))
                    })), window.addEventListener("resize", (function() {
                        t.totalItemsAdd && t.currentTotalBlocks === t.totalBlocks() ? t.listWidth = t.firstListWidth : t.listWidth = t.list.clientWidth, t.containerWidth = t.container.clientWidth, t.itemWidth = (0, n.qs)(t.blockName + "--item", t.html).clientWidth, t.manageArrowsVisibility()
                    })), (0, n.$on)(this.container, "scroll", (function() {
                        t.manageArrowsVisibility()
                    })), (0, n.$on)(this.list, "touchstart", (function(e) {
                        t.onTouchStart(e)
                    })), (0, n.$on)(this.list, "touchmove", (function(e) {
                        t.onTouchMove(e)
                    })), (0, n.forEach)(this.items, (function(e, i) {
                        var s = (0, n.qs)(t.blockName + "--link", e),
                            o = !1;
                        (0, n.$on)(e, "keyup", (function(e) {
                            9 === e.keyCode && t.animateBullets(Math.floor(i / t.totalItemsOnScreen))
                        }));
                        var l = t.html.dataset.hasAnalytics;
                        s && ("true" === l && (0, n.$on)(s, "click", (function() {
                            return t.setItemAnalytics({
                                anchor: s,
                                index: i
                            })
                        })), (0, n.$on)(s, "mousedown", (function() {
                            o = !0
                        })), (0, n.$on)(s, "focus", (function(i) {
                            o || t.handleLinkFocusScroll(i, e), o = !1
                        })), (0, n.hasClass)(s, "noAnchor") && (0, n.$on)(s, "keydown", (function(e) {
                            13 !== e.keyCode && 32 !== e.keyCode || (e.preventDefault(), "true" === l && t.setItemAnalytics({
                                anchor: s,
                                index: i
                            }))
                        })))
                    })), this.activeBullets()
                }, t.prototype.removeBlankItems = function() {
                    var t = this;
                    this.blankItems.length && ((0, n.forEach)(this.blankItems, (function(e, i) {
                        e && (e.remove(), delete t.blankItems[i])
                    })), this.totalItemsAdd = 0, this.items = (0, n.qsa)(this.blockName + "--item", this.html))
                }, t.prototype.handleItems = function() {
                    if ("block" === getComputedStyle(this.controls, null).display) {
                        for (var t = this.items.length % this.totalItemsOnScreen, e = t && this.totalItemsOnScreen - t, i = 0; i < e; i += 1) {
                            var s = (0, n.createElement)((0, n.$h)("li", {
                                className: this.blockNameForAppend + "--item",
                                "aria-hidden": "true"
                            }));
                            this.blankItems = [].concat(this.blankItems, [s]), this.list.appendChild(s)
                        }
                        this.totalItemsAdd = e
                    }
                }, t.prototype.totalBlocks = function() {
                    var t = this.items.length,
                        e = void 0;
                    return e = t % this.totalItemsOnScreen == 0 ? t / this.totalItemsOnScreen : (t - t % this.totalItemsOnScreen) / this.totalItemsOnScreen + 1, e
                }, t.prototype.animateBullets = function(t) {
                    if (this.blockNumb !== t) {
                        var e = this.blockNumb < t ? "right" : "left";
                        this.analyticsGA4Obj.toggle_type_direction = "bullet - " + e
                    } else this.analyticsGA4Obj.toggle_type_direction = "bullet";
                    this.analyticsGA4Obj.position_index = this.blockNumb + 1, this.analyticsGA4Obj.position_target = t + 1, this.analytics.pushCustomData(o({}, this.analyticsGA4Obj)), this.blockNumb = t, this.activeBullets();
                    var i = this.isRtl ? this.currentTotalBlocks - this.blockNumb - 1 : this.blockNumb,
                        s = this.itemWidth * this.totalItemsOnScreen * i,
                        n = this.isRtl ? -s : s;
                    this.animateScroll(this.container.scrollLeft, n)
                }, t.prototype.addBullets = function() {
                    for (var t = this, e = function(e) {
                            t.bullets.appendChild((0, n.createElement)((0, n.$h)("li", {
                                className: t.blockNameForAppend + "--bullet-" + e + " " + t.blockNameForAppend + "--bullet",
                                tabindex: "0"
                            })));
                            var i = (0, n.qs)(t.blockName + "--bullet-" + e, t.html);
                            (0, n.$on)(i, "mouseenter", (function(t) {
                                (0, n.addClass)(t.target, "hover")
                            })), (0, n.$on)(i, "mouseleave", (function(t) {
                                (0, n.removeClass)(t.target, "hover")
                            })), (0, n.$on)(i, "click", (function() {
                                t.animateBullets(e)
                            })), (0, n.$on)(i, "keydown", (function(i) {
                                13 === i.keyCode && t.animateBullets(e)
                            }))
                        }, i = 0; i < this.totalBlocks(); i += 1) e(i);
                    var s = this.isRtl ? (0, n.qs)(this.blockName + "--bullet-" + (this.totalBlocks() - 1), this.html) : (0, n.qs)(this.blockName + "--bullet-0", this.html);
                    (0, n.addClass)(s, "active"), this.totalBlocks() > this.maxItems && window.innerWidth <= 768 && (0, n.addClass)(this.bullets, "tenUp"), this.animateScroll(this.container.scrollLeft, 0, !0), this.currentTotalBlocks = this.totalBlocks()
                }, t.prototype.activeBullets = function() {
                    var t = (0, n.qs)(this.blockName + "--bullet-" + this.blockNumb, this.html);
                    (0, n.addClass)(t, "active"), (0, n.removeClass)(t, "hover");
                    for (var e = 0; e < this.totalBlocks(); e += 1)
                        if (e !== this.blockNumb) {
                            var i = (0, n.qs)(this.blockName + "--bullet-" + e, this.html);
                            (0, n.removeClass)(i, "active")
                        }
                }, t.prototype.randomBackgroundPosition = function() {
                    var t = this.items,
                        e = Array.isArray(t),
                        i = 0;
                    for (t = e ? t : t[Symbol.iterator]();;) {
                        var s;
                        if (e) {
                            if (i >= t.length) break;
                            s = t[i++]
                        } else {
                            if ((i = t.next()).done) break;
                            s = i.value
                        }
                        var o = s,
                            l = Math.floor(100 * Math.random()),
                            a = Math.floor(100 * Math.random());
                        if ((0, n.qs)(this.blockName + "--showMore", o)) break;
                        (0, n.qs)(this.blockName + "--link .lazy-bg", o).style.backgroundPosition = l + "% " + a + "%"
                    }
                }, t.prototype.scrollTo = function(t, e) {
                    this.isAnimating || ("right" === t && this.blockNumb < this.totalBlocks() - 1 && (this.blockNumb += 1, this.analyticsGA4Obj.toggle_type_direction = e && e + " - right", this.analyticsGA4Obj.position_index = this.blockNumb, this.analyticsGA4Obj.position_target = this.blockNumb + 1), "left" === t && this.blockNumb > 0 && (this.blockNumb -= 1, this.analyticsGA4Obj.toggle_type_direction = e && e + " - left", this.analyticsGA4Obj.position_index = this.blockNumb + 2, this.analyticsGA4Obj.position_target = this.blockNumb + 1), this.applyScroll(!0))
                }, t.prototype.getTouches = function(t) {
                    return t.touches || t.originalEvent.touches
                }, t.prototype.onTouchStart = function(t) {
                    this.lastScrollTop = window.pageYOffset || document.documentElement.scrollTop;
                    var e = this.getTouches(t)[0];
                    this.xDown = e.clientX, this.yDown = e.clientY
                }, t.prototype.onTouchMove = function(t) {
                    if (this.xDown && this.yDown) {
                        var e = t.touches[0].clientX,
                            i = t.touches[0].clientY,
                            s = this.xDown - e,
                            o = this.yDown - i;
                        Math.abs(s) > Math.abs(o) && (t.preventDefault(), s > 0 ? this.scrollTo("right", "swipe") : this.scrollTo("left", "swipe")), this.xDown = null, this.yDown = null
                    }
                }, t.prototype.applyScroll = function(t) {
                    var e, i = this,
                        s = this.isRtl ? this.currentTotalBlocks - this.blockNumb - 1 : this.blockNumb,
                        n = this.itemWidth * this.totalItemsOnScreen * s,
                        l = this.isRtl ? -n : n;
                    e = l, t ? i.animateScroll(i.container.scrollLeft, e) : i.container.scrollLeft = e, i.activeBullets(), this.analytics.pushCustomData(o({}, this.analyticsGA4Obj))
                }, t.prototype.manageArrowsVisibility = function() {
                    var t = this.blockNumb <= 0,
                        e = this.blockNumb >= this.currentTotalBlocks - 1;
                    t ? (0, n.forEach)(this.leftArrows, (function(t) {
                        t.disabled = !0
                    })) : (0, n.forEach)(this.leftArrows, (function(t) {
                        t.disabled = !1
                    })), e ? (0, n.forEach)(this.rightArrows, (function(t) {
                        t.disabled = !0
                    })) : (0, n.forEach)(this.rightArrows, (function(t) {
                        t.disabled = !1
                    }))
                }, t.prototype.handleLinkFocusScroll = function() {
                    this.applyScroll(!1)
                }, t.prototype.animateScroll = function(t, e) {
                    var i = this,
                        s = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    this.isAnimating && !s || (this.isAnimating = !0, (0, l.animate)({
                        duration: 400,
                        timing: l.easingFunctions.easeInOutQuad,
                        start: t,
                        end: e,
                        draw: function(t) {
                            i.container.scrollLeft = t
                        },
                        afterDraw: function() {
                            i.isAnimating = !1, i.manageArrowsVisibility.call(i)
                        }
                    }))
                }, t.prototype.setItemAnalytics = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = {
                            label: t.anchor.outerText || "",
                            linkText: t.anchor.href || "",
                            index: t.index + 1
                        };
                    this.setAnalytics(e)
                }, t.prototype.setAnalytics = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = t.linkText,
                        i = t.label,
                        s = {
                            event: "trackEvent",
                            category: "topic page",
                            action: (0, n.hasClass)(this.html, "cardCollection-pubReports") ? "click - publication & reports" : "click - card collection",
                            templateType: window.exxonPageType + " page"
                        },
                        o = Object.assign(s, t),
                        l = {
                            event: "card_click",
                            module_name: this.blockNameForAppend,
                            section_header: this.header.outerText || void 0,
                            link_text: i,
                            link_url: e,
                            link_type: (0, n.getLinkType)(e)
                        };
                    this.analytics.pushCustomData(o, "" + s.action), this.analytics.pushCustomData(l, "card_click GA4")
                }, t
            }();
            e.default = h
        },
        142: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var s = i(94),
                o = l(i(139)),
                n = l(i(131));

            function l(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            var a = function(t) {
                function e(i) {
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, e);
                    var o = function(t, e) {
                        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return !e || "object" != typeof e && "function" != typeof e ? t : e
                    }(this, t.call(this, i));
                    return o.html = i, o.links = (0, s.qsa)(".cta, a.highlight--section-image", i), o.content = (0, s.qs)(".highlight--content", o.html), o.analytics = new n.default, o.isRtl = "rtl" === document.querySelector("html").getAttribute("dir"), o.isFeatureGrid = (0, s.hasClass)(o.html, "featureGrid"), o.isDesktop = "desktop" === (0, s.deviceDetection)(), (0, s.forEach)(o.links, (function(t) {
                        (0, s.$on)(t, "click", o.setAnalytics.bind(o))
                    })), o.isRtl && o.content && (o.content.scrollLeft = o.content.scrollWidth), o.isFeatureGrid && o.isDesktop && o.handleItemHeight(), o
                }
                return function(t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                    t.prototype = Object.create(e && e.prototype, {
                        constructor: {
                            value: t,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                }(e, t), e.prototype.addBullets = function() {
                    var e = this;
                    if ((0, s.hasClass)(this.html, "featureGrid") || (0, s.hasClass)(this.html, "audioEFOneColumn--contentContainer")) t.prototype.addBullets.call(this);
                    else {
                        for (var i = this.bullets.dataset.bulletLabel, o = (0, s.qs)(".highlight--title h2", this.html), n = o ? (0, s.stripHtmlTags)(o.innerHTML) : "", l = function(t) {
                                var o = {
                                        className: e.blockNameForAppend + "--bullet-" + t + " " + e.blockNameForAppend + "--bullet",
                                        type: "button",
                                        "aria-pressed": "false"
                                    },
                                    l = (0, s.createElement)((0, s.$h)("button", o));
                                if (i) {
                                    var a = (0, s.stripHtmlTags)(i),
                                        r = '<span class="sr-only">' + n + " " + a + " " + (t + 1) + "</span>";
                                    l.insertAdjacentHTML("beforeend", r)
                                }
                                var h = (0, s.createElement)((0, s.$h)("li", {
                                    className: e.blockNameForAppend + "--bullet-wrapper"
                                }));
                                h.appendChild(l), e.bullets.appendChild(h);
                                var c = (0, s.qs)(e.blockName + "--bullet-" + t, e.html);
                                (0, s.$on)(c, "mouseenter", (function(t) {
                                    (0, s.addClass)(t.target, "hover")
                                })), (0, s.$on)(c, "mouseleave", (function(t) {
                                    (0, s.removeClass)(t.target, "hover")
                                })), (0, s.$on)(c, "click", (function() {
                                    e.animateBullets(t)
                                })), (0, s.$on)(c, "keydown", (function(i) {
                                    13 === i.keyCode && e.animateBullets(t)
                                }))
                            }, a = 0; a < this.totalBlocks(); a += 1) l(a);
                        var r = this.isRtl ? (0, s.qs)(this.blockName + "--bullet-" + (this.totalBlocks() - 1), this.html) : (0, s.qs)(this.blockName + "--bullet-0", this.html);
                        (0, s.addClass)(r, "active"), r && r.hasAttribute("aria-pressed") && r.setAttribute("aria-pressed", "true"), this.totalBlocks() > this.maxItems && window.innerWidth <= 768 && (0, s.addClass)(this.bullets, "tenUp"), this.animateScroll(this.container.scrollLeft, 0, !0), this.currentTotalBlocks = this.totalBlocks()
                    }
                }, e.prototype.activeBullets = function() {
                    if ((0, s.hasClass)(this.html, "featureGrid") || (0, s.hasClass)(this.html, "audioEFOneColumn--contentContainer")) t.prototype.activeBullets.call(this);
                    else {
                        var e = (0, s.qs)(this.blockName + "--bullet-" + this.blockNumb, this.html);
                        (0, s.addClass)(e, "active"), (0, s.removeClass)(e, "hover"), e && e.hasAttribute("aria-pressed") && e.setAttribute("aria-pressed", "true");
                        for (var i = 0; i < this.totalBlocks(); i += 1)
                            if (i !== this.blockNumb) {
                                var o = (0, s.qs)(this.blockName + "--bullet-" + i, this.html);
                                (0, s.removeClass)(o, "active"), o && o.hasAttribute("aria-pressed") && o.setAttribute("aria-pressed", "false")
                            }
                    }
                }, e.prototype.setAnalytics = function(t) {
                    var e = t.target.closest("a"),
                        i = e.closest(".highlight--section"),
                        o = (0, s.qs)(".highlight--section-title .h3", i).innerText,
                        n = "";
                    if ((0, s.hasClass)(e, "highlight--section-image")) {
                        var l = (0, s.qs)(".highlight--section-cta a.cta-secondary", i);
                        n = l ? l.textContent.trim() : e.getAttribute("aria-label") || ""
                    } else n = e.innerText;
                    var a = {
                        event: "trackEvent",
                        category: "" + window.exxonPageType,
                        action: "click",
                        label: o,
                        linkUrl: e.getAttribute("href"),
                        linkText: n
                    };
                    this.analytics.pushCustomData(a, "highlights")
                }, e.prototype.handleItemHeight = function() {
                    var t = (0, s.qsa)(".highlight--section", this.html),
                        e = 0,
                        i = 0;
                    (0, s.forEach)(t, (function(t) {
                        var o = (0, s.qs)(".defaultSectionTitle", t),
                            n = (0, s.qs)(".highlight--section-description", t);
                        o && o.offsetHeight > e && (e = o.offsetHeight), n && n.offsetHeight > i && (i = n.offsetHeight)
                    })), (0, s.forEach)(t, (function(t) {
                        var o = (0, s.qs)(".defaultSectionTitle", t),
                            n = (0, s.qs)(".highlight--section-description", t);
                        o && (o.style.minHeight = e + "px"), n && n.offsetHeight <= i && (n.style.minHeight = i + "px", n.style.marginBottom = "12px"), t.style.opacity = 1
                    }))
                }, e
            }(o.default);
            e.default = a
        },
        445: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.animate = function(t) {
                var e = t.duration,
                    i = t.timing,
                    s = t.start,
                    o = t.end,
                    n = t.beforeDraw,
                    l = t.draw,
                    a = t.afterDraw,
                    r = t.args;
                "function" == typeof n && n(r);
                var h = performance.now();
                requestAnimationFrame((function t(n) {
                    var c = (n - h) / e;
                    c > 1 && (c = 1);
                    var u = i(c);
                    l((o - s) * u + s, r), c < 1 ? requestAnimationFrame(t) : 1 === c && "function" == typeof a && a(r)
                }))
            }, e.getBordersIfItemIsNotInView = function(t, e, i) {
                var s = {
                        isNotInView: !1
                    },
                    o = t.offsetLeft,
                    n = t.offsetLeft + t.clientWidth,
                    l = i.clientWidth,
                    a = Math.round(i.scrollLeft);
                ("left" === e || "both" === e) && a - o > 0 && a - n <= 0 ? (s.borderLeftPos = o, s.borderRightPos = n, s.direction = "left", s.isNotInView = !0) : ("right" === e || "both" === e) && n > l + a && (s.borderLeftPos = o, s.borderRightPos = n, s.direction = "right", s.isNotInView = !0);
                return s
            };
            e.easingFunctions = {
                linear: function(t) {
                    return t
                },
                easeInQuad: function(t) {
                    return t * t
                },
                easeOutQuad: function(t) {
                    return t * (2 - t)
                },
                easeInOutQuad: function(t) {
                    return t < .5 ? 2 * t * t : (4 - 2 * t) * t - 1
                },
                easeInCubic: function(t) {
                    return t * t * t
                },
                easeOutCubic: function(t) {
                    return --t * t * t + 1
                },
                easeInOutCubic: function(t) {
                    return t < .5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1
                },
                easeInQuart: function(t) {
                    return t * t * t * t
                },
                easeOutQuart: function(t) {
                    return 1 - --t * t * t * t
                },
                easeInOutQuart: function(t) {
                    return t < .5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t
                },
                easeInQuint: function(t) {
                    return t * t * t * t * t
                },
                easeOutQuint: function(t) {
                    return 1 + --t * t * t * t * t
                },
                easeInOutQuint: function(t) {
                    return t < .5 ? 16 * t * t * t * t * t : 1 + 16 * --t * t * t * t * t
                }
            }
        }
    }
]);