(window.webpackJsonp = window.webpackJsonp || []).push([
    [88, 32], {
        132: function(t, e, s) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = s(94);
            var a = ["a[href]:not([disabled])", "button:not([disabled])", "textarea:not([disabled])", 'input[type="text"]:not([disabled])', 'input[type="radio"]:not([disabled])', 'input[type="checkbox"]:not([disabled])', 'select:not([disabled]):not([tabindex="-1"])', '[tabindex]:not([tabindex="-1"])'],
                n = function() {
                    function t(e) {
                        var s = e.html,
                            n = void 0 === s ? document.body : s,
                            o = e.reloaded,
                            l = void 0 !== o && o,
                            h = e.selectorsList,
                            r = void 0 === h ? a : h,
                            m = e.defaultFocus,
                            u = e.ignoreElement;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.html = n, this.defaultFocus = m, this.body = (0, i.qs)("body"), this.KEYCODE_TAB = 9, this.selectorsList = r.join(), this.ignoreElement = u, this.hiddenElements = [], this.setFocusableElements(), this.trapFocusReference = this.trapFocus.bind(this), l || (this.defaultFocus ? this.defaultFocus.focus() : this.firstFocusableEl.focus()), (0, i.$on)(window, "keydown", this.trapFocusReference)
                    }
                    return t.prototype.trapFocus = function(t) {
                        ("Tab" === t.key || t.keyCode === this.KEYCODE_TAB) && (t.shiftKey ? document.activeElement === this.firstFocusableEl && (this.lastFocusableEl.focus(), t.preventDefault()) : document.activeElement === this.lastFocusableEl && (this.firstFocusableEl.focus(), t.preventDefault()))
                    }, t.prototype.setFocusableElements = function() {
                        var t = this;
                        this.focusableElements = (0, i.qsa)(this.selectorsList, this.html), this.ignoreElement && (this.focusableElements = Array.from(this.focusableElements).filter((function(e) {
                            return !(0, i.hasClass)(e, t.ignoreElement)
                        })));
                        var e = this.focusableElements;
                        this.firstFocusableEl = e[0], this.lastFocusableEl = this.focusableElements[this.focusableElements.length - 1], this.setMobileFocusLoop()
                    }, t.prototype.removeTrapFocus = function() {
                        (0, i.forEach)(this.hiddenElements, (function(t) {
                            t.removeAttribute("aria-hidden"), t.removeAttribute("inert")
                        })), (0, i.$off)(window, "keydown", this.trapFocusReference)
                    }, t.prototype.setMobileFocusLoop = function() {
                        for (var t = this.html; t !== this.body;) {
                            for (var e = t.parentNode.childNodes, s = 0; s < e.length; s += 1) {
                                var a = e[s];
                                a && a.classList && (0, i.hasClass)(a, "skip-content") || a.id && "onetrust-consent-sdk" === a.id || a !== t && a.setAttribute && (a.setAttribute("inert", ""), a.setAttribute("aria-hidden", "true"), this.hiddenElements = [].concat(this.hiddenElements, [a]))
                            }
                            t = t.parentNode
                        }
                    }, t
                }();
            e.default = n
        },
        185: function(t, e, s) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = s(94),
                a = o(s(131)),
                n = o(s(132));

            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            var l = function(t) {
                    (0, i.removeClass)(t, "openItem"), t.nextElementSibling && (0, i.removeClass)(t.nextElementSibling, "openItem")
                },
                h = function() {
                    document.dispatchEvent(new CustomEvent("openSearch", {
                        detail: {
                            close: !0
                        }
                    })), document.dispatchEvent(new CustomEvent("openHomePopUp", {
                        detail: {
                            close: !0
                        }
                    }))
                },
                r = function() {
                    function t(e) {
                        var s = this;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.html = e, this.globalBody = (0, i.qs)("body"), this.mainWrapper = (0, i.qs)(".mainNav--wrapper", this.html), this.mainLogo = (0, i.qs)(".mainNav--logo", this.html), this.navList = (0, i.qs)(".mainNav--list", this.html), this.navAside = (0, i.qs)(".mainNav--aside", this.html), this.hamburgerBtn = (0, i.qsa)(".mainNav--mobile-icon", this.html), this.listParentItem = (0, i.qsa)(".mainNav--parent", this.html), this.listItem = (0, i.qsa)(".mainNav--listItem", this.html), this.itemTitle = (0, i.qsa)("mainNav--itemTitle", this.html), this.parentItemTitles = (0, i.qsa)(".mainNav--parent.mainNav--itemTitle", this.html), this.overlay = (0, i.qs)(".mainNav--overlay", this.html), this.utilities = (0, i.qs)(".mainNav--utilities", this.html), this.subNav = (0, i.qsa)(".subNav", this.html), this.subNavTitle = (0, i.qsa)(".subNav--sectionTitle"), this.searchBtn = (0, i.qs)(".mainNav--search-icon", this.html), this.globalBtn = (0, i.qs)(".mainNav--globalSelector", this.html) || this.searchBtn, this.globalSelector = (0, i.qs)(".globalSelector"), this.sectionLinks = (0, i.qsa)(".subNav--sectionLinks a", this.html), this.anchors = (0, i.qsa)("a", this.html), this.focusableListItems = (0, i.qsa)("a[href], button", this.html), this.indexAbleListItems = [], this.listOffWidth = this.navList ? this.navList.offsetWidth : 0, this.minPaddingViewport = 60, this.lateralNavPadding = 80, this.spaceB = 0, this.menuItems = [], this.subMenuItems = {
                            first: "",
                            last: ""
                        }, this.POSITION = {
                            FIRST: "first",
                            LAST: "last",
                            NEXT: "next",
                            PRE: "previous"
                        }, this.tabindex = {
                            focusableElements: "",
                            lastFocusableElement: "",
                            firstFocusableElement: ""
                        }, this.analytics = new a.default, this.globalBody.offsetWidth < 1100 && this.calculateMenu(), (0, i.forEach)(this.hamburgerBtn, (function(t) {
                            (0, i.$on)(t, "click", s.toggleHamburgerMenu.bind(s))
                        })), (0, i.$on)(this.overlay, "click", this.toggleHamburgerMenu.bind(this)), this.navList && ((0, i.$on)(this.navList, "touchstart", (function() {})), (0, i.$on)(this.mainWrapper, "mouseleave", this.hoverOnHomeMenuLeave.bind(this))), (0, i.forEach)(this.listParentItem, (function(t) {
                            (0, i.$on)(t, "click", s.unifiedMenuClickHandler.bind(s)), (0, i.$on)(t, "touchend", s.mobileSubMenuAccordion.bind(s))
                        })), (0, i.$on)(this.mainWrapper, i.isIE11 ? "mouseover" : "mouseenter", this.hoverOnHomeMenuEnter.bind(this)), (0, i.forEach)(this.listItem, (function(t) {
                            (0, i.$on)(t, i.isIE11 ? "mouseover" : "mouseenter", (function(e) {
                                (0, i.addClass)(t, "active"), s.hoverOnItemEnter(e), s.setCurrentPosition(e), s.hoverOnHomeMenuEnter()
                            })), s.initialSubmenuItem = null, s.menuItemList = null;
                            var e = (0, i.qs)(".mainNav--itemTitle", t);
                            (0, i.$on)(e, "focus", s.onFocusMenuItems.bind(s)), (0, i.$on)(t, "mouseleave", s.blurAllMenuItems.bind(s)), (0, i.$on)(t, "mouseleave", s.removeCurrentPosition.bind(s))
                        })), (0, i.$on)(window, "keydown", this.handleKeyPress.bind(this)), this.registerTabElements(!0), this.addMobileMenuAnimation();
                        var n = window.matchMedia("(min-width: 1100px)");
                        n.addListener(this.handleMediaQueryChange.bind(this)), this.handleMediaQueryChange(n), (0, i.$on)(window, "resize", this.createMobileMenu.bind(this)), (0, i.$on)(document, "openHomePopUp", (function(t) {
                            t.stopPropagation(), t.detail && t.detail.close ? s.closePopUp() : s.togglePopUps()
                        })), (0, i.forEach)(this.subNav, (function(t) {
                            s.subNavClasses(t)
                        })), this.mainLogo && ((0, i.$on)(this.mainLogo, "click", this.clickMainLogo.bind(this)), (0, i.forEach)(this.anchors, (function(t) {
                            (0, i.$on)(t, "click", s.handleAnalyticsNavClick.bind(s))
                        }))), (0, i.forEach)(this.listItem, (function(t) {
                            (0, i.$on)(t, "mouseover", s.analyticsSubItemHoverHandler.bind(s))
                        })), (0, i.forEach)(this.sectionLinks, (function(t) {
                            (0, i.$on)(t, "click", s.analyticsSubItemClickHandler.bind(s)), (0, i.$on)(t, "focus", (function(t) {
                                if (!(0, i.hasClass)(s.html, "mainNav-collapsible")) {
                                    var e = (0, i.closest)(t.target, ".mainNav--listItem");
                                    (0, i.addClass)(e, "active")
                                }
                            }))
                        })), this.initIndexKeyboard()
                    }
                    return t.prototype.initIndexKeyboard = function() {
                        var t = this,
                            e = 0;
                        (0, i.forEach)(this.focusableListItems, (function(s) {
                            (0, i.hasClass)(s, "mainNav--itemTitle") || (0, i.hasClass)(s.parentNode, "mobile-cta") || (t.indexAbleListItems = [].concat(t.indexAbleListItems, [s]), s.dataset.indexKeyboard = e, e += 1)
                        }));
                        var s = 0;
                        (0, i.forEach)(this.parentItemTitles, (function(t) {
                            t.dataset.indexLeftRight = s, s += 1
                        }))
                    }, t.prototype.setCurrentPosition = function(t) {
                        var e = (0, i.hasClass)(t.target, "mainNav--listItem") ? t.target : (0, i.closest)(t.target, ".mainNav--listItem"),
                            s = (0, i.qs)(".subNav", e),
                            a = (0, i.qs)(".mainNav--itemTitle", e),
                            n = s.getBoundingClientRect();
                        i.isChrome ? this.blurAllMenuItems() : e.previousElementSibling ? (0, i.removeClass)(e.previousElementSibling, "active") : e.nextElementSibling && (0, i.removeClass)(e.nextElementSibling, "active"), (0, i.addClass)(e, "active"), (0, i.addClass)(this.navList, "active-menu"), a.setAttribute("aria-expanded", !0), (0, i.hasClass)(s, "subNav-four") || (0, i.addClass)(e, "subNav-relative"), window.innerWidth - n.right < 20 && !(0, i.hasClass)(s, "subNav-center") && !(0, i.hasClass)(s, "subNav-four") && (0, i.addClass)(s, "subNav-center"), (n = s.getBoundingClientRect()).left < 20 && !(0, i.hasClass)(s, "subNav-right") && !(0, i.hasClass)(s, "subNav-four") && (0, i.addClass)(s, "subNav-right"), window.innerWidth - n.right < 20 && ((0, i.hasClass)(s, "subNav-center") || (0, i.hasClass)(s, "subNav-two")) && ((0, i.removeClass)(s, "subNav-right subNav-center"), (0, i.addClass)(s, "subNav-left"))
                    }, t.prototype.removeCurrentPosition = function(t) {
                        var e = (0, i.hasClass)(t.target, "mainNav--listItem") ? t.target : (0, i.closest)(t.target, ".mainNav--listItem"),
                            s = (0, i.qs)(".subNav", e);
                        (0, i.removeClass)(s, "subNav-right subNav-left subNav-center"), (0, i.removeClass)(e, "subNav-relative")
                    }, t.prototype.subNavClasses = function(t) {
                        var e = 0;
                        switch ((0, i.forEach)([".mobile-cta"], (function(s) {
                            e += (0, i.qsa)(s, t).length
                        })), t.children.length - e) {
                            case 3:
                                (0, i.addClass)(t, "subNav-three");
                                break;
                            case 2:
                                (0, i.addClass)(t, "subNav-two");
                                break;
                            case 1:
                                (0, i.addClass)(t, "subNav-one");
                                break;
                            case 4:
                            default:
                                (0, i.addClass)(t, "subNav-four")
                        }
                    }, t.prototype.addMobileMenuAnimation = function() {
                        var t = "string" == typeof document.documentElement.style.transition ? "transition" : "WebkitTransition";
                        (0, i.forEach)(this.itemTitle, (function(e, s) {
                            e.style[t + "Delay"] = (s + 2) / 18 + "s"
                        }))
                    }, t.prototype.removeMobileMenuAnimation = function() {
                        (0, i.forEach)(this.itemTitle, (function(t) {
                            t.removeAttribute("style")
                        }))
                    }, t.prototype.unifiedMenuClickHandler = function(t) {
                        var e = "desktop" === (0, i.deviceDetection)(),
                            s = "BUTTON" === t.target.tagName;
                        e && s ? this.enterKeyToOpenSubMenu(t) : this.mobileSubMenuAccordion(t)
                    }, t.prototype.mobileSubMenuAccordion = function(t) {
                        if ((0, i.hasClass)(this.html, "mainNav-collapsible")) {
                            var e = (0, i.qsa)(".mainNav--itemTitle", this.html),
                                s = (0, i.qsa)(".subNav--sectionTitle", this.html);
                            t.preventDefault(), (0, i.hasClass)(t.target, "subNav--sectionTitle") ? (0, i.forEach)(s, (function(e) {
                                e !== t.target && l(e)
                            })) : (0, i.forEach)(e, (function(e) {
                                e !== t.target && (l(e), (0, i.forEach)(s, (function(t) {
                                    l(t)
                                })))
                            })), (0, i.toggleClass)(t.target, "openItem"), (0, i.toggleClass)(t.target.nextElementSibling, "openItem"), "touchend" === t.type && t.target.focus(), (0, i.hasClass)(t.target, "openItem") && this.analyticsSubitemHandler(t.target)
                        }
                    }, t.prototype.mobileMenuCloseItems = function() {
                        var t = (0, i.qsa)(".openItem", this.html);
                        this.blurAllMenuItems(), (0, i.forEach)(t, (function(t) {
                            (0, i.removeClass)(t, "openItem")
                        }))
                    }, t.prototype.handleMediaQueryChange = function(t) {
                        (0, i.removeClass)(this.html, "mainNav-collapsible"), t.matches && this.calculateMenu()
                    }, t.prototype.calculateMenu = function() {
                        var t = this;
                        setTimeout((function() {
                            var e = t.mainLogo ? t.mainLogo.offsetWidth : 0,
                                s = t.utilities ? t.utilities.offsetWidth : 0;
                            t.spaceB = t.listOffWidth + e + s + t.lateralNavPadding
                        }), 50), setTimeout((function() {
                            t.mainWrapper.removeAttribute("style"), (0, i.removeClass)(t.html, "mainNav-hidden"), t.createMobileMenu()
                        }), 100)
                    }, t.prototype.createMobileMenu = function() {
                        this.mainWrapper.offsetWidth - this.spaceB <= this.minPaddingViewport || "desktop" !== (0, i.deviceDetection)() ? ((0, i.forEach)(this.subNavTitle, (function(t) {
                            t.setAttribute("tabindex", "0")
                        })), (0, i.forEach)(this.listItem, (function(t) {
                            (0, i.removeClass)(t, "active"), (0, i.removeClass)(t, "subNav-relative")
                        })), (0, i.addClass)(this.html, "mainNav-collapsible"), this.addMobileMenuAnimation()) : ((0, i.forEach)(this.subNavTitle, (function(t) {
                            t.setAttribute("tabindex", "-1")
                        })), (0, i.removeClass)(this.html, "mainNav-collapsible"), this.removeMobileMenuAnimation(), this.mobileMenuCloseItems(), this.navAside && ((0, i.removeClass)(this.navAside, "mobileNavOpen"), (0, i.removeClass)(this.navAside, "animated")), (0, i.removeClass)(this.overlay, "openOverlay"), this.globalSelector && !(0, i.hasClass)(this.globalSelector, "show") && (0, i.removeClass)(this.globalBody, "_prevent-scroll"))
                    }, t.prototype.toggleHamburgerMenu = function() {
                        var t = this;
                        (0, i.hasClass)(this.navAside, "animated") ? (this.tabTrap.removeTrapFocus(), this.tabTrap = null, this.hamburgerBtn[0].focus(), setTimeout((function() {
                            (0, i.removeClass)(t.navAside, "animated"), t.navAside.style.display = ""
                        }), 300)) : (this.navAside.style.display = "block", (0, i.addClass)(this.navAside, "animated"), h(), this.tabTrap = new n.default({
                            html: this.navAside,
                            selectorsList: [".mainNav--itemTitle", ".subNav.openItem .subNav--sectionTitle", ".subNav--sectionLinks.openItem a", ".mainNav--mobile-icon"]
                        })), (0, i.toggleClass)(this.navAside, "mobileNavOpen"), (0, i.toggleClass)(this.globalBody, "_prevent-scroll"), (0, i.toggleClass)(this.overlay, "openOverlay"), this.mobileMenuCloseItems()
                    }, t.prototype.togglePopUps = function() {
                        (0, i.hasClass)(this.html, "mainNav-home") && (0, i.toggleClass)(this.html, "mainNav-popUpOpened"), (0, i.hasClass)(this.html, "mainNav-home") && (0, i.hasClass)(this.html, "mainNav-collapsible") && (0, i.toggleClass)(this.html, "mainNav-transparent"), (0, i.hasClass)(this.html, "mainNav-popUpOpened") && (0, i.removeClass)(this.html, "mainNav-transparent")
                    }, t.prototype.hoverOnHomeMenuEnter = function() {
                        (0, i.hasClass)(this.html, "mainNav-home") && !(0, i.hasClass)(this.html, "mainNav-collapsible") && (0, i.removeClass)(this.html, "mainNav-transparent")
                    }, t.prototype.hoverOnHomeMenuLeave = function() {
                        !(0, i.hasClass)(this.html, "mainNav-home") || (0, i.hasClass)(this.html, "mainNav-collapsible") || (0, i.hasClass)(this.html, "mainNav-popUpOpened") || (0, i.hasClass)(this.navList, "active-menu") || (0, i.addClass)(this.html, "mainNav-transparent")
                    }, t.prototype.hoverOnItemEnter = function() {
                        this.closePopUp("hover"), h()
                    }, t.prototype.closePopUp = function(t) {
                        ((0, i.hasClass)(this.searchBtn, "open") || (0, i.hasClass)(this.globalBtn, "open")) && ((0, i.removeClass)(this.searchBtn, "open"), (0, i.removeClass)(this.globalBtn, "open"), (0, i.removeClass)(this.html, "mainNav-popUpOpened")), (0, i.hasClass)(this.html, "mainNav-home") && "hover" !== t && (0, i.addClass)(this.html, "mainNav-transparent")
                    }, t.prototype.clickMainLogo = function(t) {
                        var e = {
                            event: "nav_click",
                            module_name: "header logo",
                            link_text: t.target.alt || void 0,
                            link_url: t.target.parentNode.href,
                            link_type: (0, i.getLinkType)(t.target.parentNode.href)
                        };
                        this.analytics.pushCustomData({
                            event: "trackEvent",
                            category: "navigation",
                            action: "click - primary nav",
                            label: "logo"
                        }, "click main logo"), this.analytics.pushCustomData(e, "nav_click GA4")
                    }, t.prototype.handleKeyPress = function(t) {
                        switch (t.keyCode) {
                            case 9:
                                this.tabKeyActiveElements(t);
                                break;
                            case 13:
                                this.enterKeyToOpenSubMenu(t);
                                break;
                            case 27:
                                this.handleEscKeyInTopNav();
                                break;
                            case 37:
                                this.handleLeftRightInTopNav(t);
                                break;
                            case 38:
                                this.handlePressArrow(t, "up");
                                break;
                            case 39:
                                this.handleLeftRightInTopNav(t);
                                break;
                            case 40:
                                this.handlePressArrow(t, "down")
                        }
                    }, t.prototype.handleLeftRightInTopNav = function(t) {
                        var e = (0, i.hasClass)(t.target, "mainNav--parent"),
                            s = (0, i.qs)(".active", this.navAside);
                        if (s || e) {
                            var a = void 0,
                                n = void 0;
                            if (e) a = t.target.dataset.indexLeftRight;
                            else if (s) {
                                this.handleEscKeyInTopNav(), a = (0, i.qs)(".mainNav--parent", s).dataset.indexLeftRight
                            }
                            switch (t.keyCode) {
                                case 37:
                                    (n = +a - 1) < 0 && (n = this.parentItemTitles.length - 1);
                                    break;
                                case 39:
                                    (n = +a + 1) === this.parentItemTitles.length && (n = 0)
                            }
                            this.parentItemTitles[n].focus()
                        }
                    }, t.prototype.handlePressArrow = function(t, e) {
                        var s = "up" === e;
                        (0, i.hasClass)(t.target, "mainNav--parent") ? (this.enterKeyToOpenSubMenu(t, s), t.preventDefault()) : "menuitem" !== t.target.role && "A" !== t.target.nodeName || (this.focusMenuItem(t, this.POSITION[s ? "PRE" : "NEXT"]), t.preventDefault())
                    }, t.prototype.handleEscKeyInTopNav = function() {
                        var t = (0, i.qs)(".active", this.html),
                            e = (0, i.qs)(".mainNav--parent", t),
                            s = (0, i.qs)(".active-menu", this.html),
                            a = (0, i.hasClass)(this.html, "mainNav-collapsible"),
                            n = (0, i.hasClass)(this.navAside, "mobileNavOpen");
                        a ? n && this.toggleHamburgerMenu() : (this.closePopUp(), this.blurAllMenuItems()), s && e.focus()
                    }, t.prototype.enterKeyToOpenSubMenu = function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        if (t.stopPropagation(), 13 !== t.keyCode || "A" !== t.target.tagName) {
                            var s = (0, i.hasClass)(this.html, "mainNav-collapsible"),
                                a = (0, i.hasClass)(t.target, "mainNav--itemTitle"),
                                n = (0, i.hasClass)(t.target, "subNav--sectionTitle"),
                                o = !!this.initialSubmenuItem;
                            s && (a || n) ? (this.mobileSubMenuAccordion(t), this.tabTrap && this.tabTrap.setFocusableElements()) : !s && a && o && ((0, i.addClass)(this.menuItemList, "active"), this.hoverOnItemEnter(t), this.setCurrentPosition(t), this.hoverOnHomeMenuEnter(), this.focusMenuItem(t, e ? this.POSITION.LAST : this.POSITION.FIRST))
                        }
                    }, t.prototype.focusMenuItem = function(t, e) {
                        var s, a = this;
                        if (t) {
                            var n = e;
                            (0, i.hasClass)(t.target.parentNode, "mainNav--listItem") && (this.menuItems = (0, i.qsa)("a", t.target.parentNode), (0, i.forEach)(this.menuItems, (function(e) {
                                (0, i.hasClass)(e.parentNode, "mobile-cta") && (e.remove(), a.menuItems = (0, i.qsa)("a", t.target.parentNode))
                            })));
                            var o = this.menuItems.length - 1,
                                l = t.target.dataset.indexKeyboard,
                                h = +l + 1,
                                r = +l - 1,
                                m = this.subMenuItems.last === this.indexAbleListItems[+l],
                                u = this.subMenuItems.first === this.indexAbleListItems[+l],
                                c = (0, i.hasClass)(this.menuItems[0], "mainNav--parent") ? this.menuItems[1] : this.menuItems[0];
                            e === this.POSITION.FIRST || e === this.POSITION.LAST ? (this.subMenuItems.last = this.menuItems[o], this.subMenuItems.first = c) : e === this.POSITION.NEXT && m ? n = this.POSITION.FIRST : e === this.POSITION.PRE && u && (n = this.POSITION.LAST), ((s = {})[this.POSITION.FIRST] = c, s[this.POSITION.LAST] = this.menuItems[o], s[this.POSITION.NEXT] = this.indexAbleListItems[h], s[this.POSITION.PRE] = this.indexAbleListItems[r], s)[n].focus()
                        }
                    }, t.prototype.tabKeyActiveElements = function(t) {
                        var e = "BODY" === document.activeElement.tagName ? (0, i.qs)(".mainNav--listItem.active", this.navList) : document.activeElement;
                        1 === this.tabindex.focusableElements.length ? t.preventDefault() : (document.activeElement === this.tabindex.lastFocusableElement && !t.shiftKey || e === this.tabindex.firstFocusableElement && t.shiftKey) && this.blurAllMenuItems()
                    }, t.prototype.blurAllMenuItems = function() {
                        (0, i.forEach)(this.listItem, (function(t) {
                            t.blur(), (0, i.removeClass)(t, "active"), (0, i.qs)(".mainNav--itemTitle", t).setAttribute("aria-expanded", !1)
                        })), this.navList && (0, i.removeClass)(this.navList, "active-menu")
                    }, t.prototype.registerTabElements = function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        this.tabindex.focusableElements = (0, i.qsa)("a[href], .mainNav--listItem", this.navList), t && (this.tabindex.firstFocusableElement = this.tabindex.focusableElements[0]), this.tabindex.lastFocusableElement = this.tabindex.focusableElements[this.tabindex.focusableElements.length - 1]
                    }, t.prototype.onFocusMenuItems = function(t) {
                        this.initialSubmenuItem = (0, i.qs)("a", t.target.nextElementSibling), this.menuItemList = (0, i.closest)(t.target, ".mainNav--listItem"), this.blurAllMenuItems(), this.closePopUp()
                    }, t.prototype.analyticsSubItemHoverHandler = function(t) {
                        "desktop" === (0, i.deviceDetection)() && "mouseover" === t.type && ((0, i.hasClass)(t.target, "mainNav--itemTitle") || (0, i.hasClass)(t.target, "subNav--sectionTitle")) && this.analyticsSubitemHandler(t.target)
                    }, t.prototype.analyticsSubItemClickHandler = function(t) {
                        this.analyticsSubitemHandler(t.target)
                    }, t.prototype.analyticsSubitemHandler = function(t) {
                        var e = "tier 1";
                        (0, i.hasClass)(t, "mainNav--itemTitle") ? this.openItemAnalytics(t.innerText, e): (0, i.hasClass)(t, "subNav--sectionTitle") ? (e = "tier 2", this.openItemAnalytics(t.innerText, e)) : "A" === t.nodeName && (e = "tier 3", this.openItemAnalytics(t.innerText, e))
                    }, t.prototype.openItemAnalytics = function(t, e) {
                        var s = {
                            event: "trackEvent",
                            category: "navigation",
                            action: "click - primary nav",
                            primaryNavTier: e,
                            label: t
                        };
                        this.analytics.pushCustomData(s, "open tier " + e + " - " + t)
                    }, t.prototype.handleAnalyticsNavClick = function(t) {
                        if (!(0, i.hasClass)(t.target, "mainNav--logoRed") && !(0, i.hasClass)(t.target, "mainNav--logoWhite")) {
                            var e = {
                                event: "nav_click",
                                module_name: (0, i.hasClass)(this.html, "mainNav-collapsible") ? "mobile nav" : "main nav",
                                link_text: t.target.innerText,
                                link_url: t.target.href,
                                link_type: (0, i.getLinkType)(t.target.href)
                            };
                            this.analytics.pushCustomData(e, "nav_click GA4")
                        }
                    }, t
                }();
            e.default = r
        }
    }
]);