(window.webpackJsonp = window.webpackJsonp || []).push([
    [70], {
        170: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var o = i(94),
                s = a(i(451)),
                n = a(i(131));

            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            var r = function() {
                function t(e) {
                    var i = this;
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), this.html = e, this.speed = e.dataset.speed || 2e3, this.carouselItems = (0, o.qsa)(".homeHero--item", e), this.bullets = (0, o.qsa)(".homeHero--itemCta", this.html), this.positionIndicator = (0, o.qs)(".homeHero--pos", e), this.carouselItemsIndicator = (0, o.qsa)(".homeHero--itemTitle", e), this.downArrow = (0, o.qs)(".icon-down-arrow", e), this.sliderMask = (0, o.qs)(".homeHero--content", e);
                    var s = this.carouselItems;
                    this.currentSlide = s[0];
                    var a = this.carouselItemsIndicator;
                    this.currentSlideIndicator = a[0], this.currentPos = 0, this.longTouch = !1, this.carouselVerticalScroll = !1, this.sceneSize = (0, o.qs)(".homeHero--item", e).clientWidth, this.moveX = 0, this.HTMLNODE = (0, o.qs)("html"), this.buttonLinks = (0, o.qsa)(".homeHero--ctaContainer a", e), this.analytics = new n.default, this.playPauseBtn = (0, o.qs)(".homeHero--playBtn", this.html), this.iframe = (0, o.qs)("iframe.xom-youtube-video", this.html), this.statusEl = (0, o.qs)("#carouselStatus", this.html), this.configSlider(), (0, o.$on)(this.downArrow, "click", this.scrollAfterHero.bind(this)), (0, o.forEach)(this.buttonLinks, (function(t) {
                        (0, o.$on)(t, "click", i.setAnalyticsLink.bind(i))
                    })), this.iframe && document.dispatchEvent(new CustomEvent("homeHero--video"))
                }
                return t.prototype.configSlider = function() {
                    var t = this;
                    this.carouselItems.length > 1 && (this.setDynamicClass(this.carouselItems.length), this.positionIndicatorSize(), this.updateCurrentSlide(0), (0, o.removeClass)(this.html, "homeHero-loading"), this.colorPositionIndicator(this.carouselItemsIndicator[0].parentElement.dataset.color), (0, o.forEach)(this.carouselItemsIndicator, (function(e, i) {
                        (0, o.$on)(e, "click", t.updateSliderEvent.bind(t)), 0 === i && t.movePositionIndicator(e.offsetLeft)
                    })), (0, o.$on)(window, "resize", this.updatePositionResize.bind(this)), (0, o.$on)(this.sliderMask, "touchstart", this.onTouchStart.bind(this)), (0, o.$on)(this.sliderMask, "touchmove", this.onTouchMove.bind(this)), (0, o.$on)(this.sliderMask, "touchend", this.onTouchEnd.bind(this)), (0, o.$on)(this.playPauseBtn, "click", this.manageControls.bind(this)), (0, o.$on)(this.playPauseBtn, "focus", this.hiddenMainContent.bind(this)), (0, o.forEach)(this.bullets, (function(e) {
                        (0, o.$on)(e, "click", (function(e) {
                            t.goToSlide(+e.target.dataset.pos)
                        }))
                    })), this.setAutoSlide())
                }, t.prototype.setAutoSlide = function() {
                    this.timerAutoSlide = setInterval(this.goToNextSlide.bind(this), this.speed)
                }, t.prototype.announceCarouselStatus = function(t) {
                    if (this.statusEl) {
                        var e = "";
                        switch (t) {
                            case "play":
                                e = this.statusEl.getAttribute("data-play");
                                break;
                            case "pause":
                                e = this.statusEl.getAttribute("data-pause");
                                break;
                            default:
                                e = t
                        }
                        this.statusEl.textContent = e
                    }
                }, t.prototype.hiddenMainContent = function() {
                    this.carouselItems.length <= 2 || (this.sliderMask.setAttribute("aria-hidden", "true"), this.sliderMask.setAttribute("tabindex", "-1"), this.carouselItems.forEach((function(t) {
                        t.setAttribute("tabindex", "-1"), t.setAttribute("aria-hidden", "true")
                    })))
                }, t.prototype.manageControls = function() {
                    (0, o.hasClass)(this.playPauseBtn, "icon-play-btn") ? (this.setAutoSlide(), (0, o.removeClass)(this.playPauseBtn, "icon-play-btn"), (0, o.addClass)(this.playPauseBtn, "icon-pause-btn"), (0, o.removeClass)(this.html, "paused"), this.announceCarouselStatus("play")) : (this.announceCarouselStatus("pause"), this.pauseHero())
                }, t.prototype.pauseHero = function() {
                    clearInterval(this.timerAutoSlide), (0, o.removeClass)(this.playPauseBtn, "icon-pause-btn"), (0, o.addClass)(this.playPauseBtn, "icon-play-btn"), (0, o.addClass)(this.html, "paused")
                }, t.prototype.scrollAfterHero = function() {
                    var t = this.html.clientHeight + window.pageYOffset + this.html.getBoundingClientRect().top;
                    (0, s.default)(t, 300)
                }, t.prototype.movePositionIndicator = function(t) {
                    this.positionIndicator.style.left = t + "px"
                }, t.prototype.colorPositionIndicator = function(t) {
                    var e = "#FE000C";
                    "" !== t && t || !(0, o.qs)(".theme-blue") || (e = "#2369bd"), this.positionIndicator.style.background = e
                }, t.prototype.goToNextSlide = function() {
                    var t = this.currentPos + 1;
                    this.currentPos === this.carouselItems.length - 1 && (t = 0), this.goToSlide(t)
                }, t.prototype.goToPrevSlide = function() {
                    var t = this.currentPos - 1;
                    0 === this.currentPos && (t = this.carouselItems.length - 1), this.goToSlide(t)
                }, t.prototype.goToSlide = function(t) {
                    var e = (0, o.qsa)(".homeHero--itemTitle", this.html);
                    e[t] && (this.movePositionIndicator(e[t].offsetLeft), this.colorPositionIndicator(e[t].parentElement.dataset.color), this.updateCurrentSlide(t))
                }, t.prototype.updateCurrentSlide = function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        i = (0, o.qs)(".homeHero--itemWrapper", this.carouselItems[t]);
                    if ((0, o.removeClass)(this.currentSlideIndicator.parentElement, "active"), (0, o.addClass)(this.carouselItemsIndicator[t].parentElement, "active"), (0, o.removeClass)(this.currentSlide, "active"), (0, o.addClass)(this.carouselItems[t], "active"), this.currentPos = t, this.currentSlideIndicator = this.carouselItemsIndicator[t], this.currentSlide = this.carouselItems[t], this.resetFocusable(this.currentSlideIndicator), e) {
                        (0, o.forEach)(this.carouselItemsIndicator, (function(e, i) {
                            i !== t && e.setAttribute("aria-hidden", "true")
                        }));
                        var s = (0, o.qs)("*", i);
                        s.setAttribute("tabindex", "0"), s.focus(), setTimeout((function() {
                            s.removeAttribute("tabindex")
                        }), 100)
                    }
                }, t.prototype.resetFocusable = function(t) {
                    var e = this;
                    (0, o.$on)(t, "focus", (function() {
                        (0, o.forEach)(e.carouselItemsIndicator, (function(t) {
                            t.removeAttribute("aria-hidden")
                        }))
                    }))
                }, t.prototype.updatePositionResize = function() {
                    this.carouselItems = (0, o.qsa)(".homeHero--item", this.html), this.activeIndicator = (0, o.qs)(".homeHero--itemCta.active .homeHero--itemTitle", this.html), this.movePositionIndicator(this.activeIndicator.offsetLeft), this.positionIndicatorSize()
                }, t.prototype.updateSliderEvent = function(t) {
                    var e = t.target,
                        i = (0, o.closest)(e, ".homeHero--itemCta"),
                        s = i.dataset.pos,
                        n = i.dataset.color;
                    clearTimeout(this.timerAutoSlide), this.movePositionIndicator(e.offsetLeft), this.colorPositionIndicator(n), this.updateCurrentSlide(parseInt(s, 10), "click" === t.type), this.setAutoSlide(), this.setAnalyticsTab(), this.pauseHero()
                }, t.prototype.positionIndicatorSize = function() {
                    this.positionIndicator.style.width = (0, o.qs)(".homeHero--itemTitle", this.html).clientWidth + "px"
                }, t.prototype.setDynamicClass = function(t) {
                    var e = void 0;
                    switch (t) {
                        case 2:
                            e = "jsTwo";
                            break;
                        case 3:
                            e = "jsThree";
                            break;
                        case 4:
                            e = "jsFour"
                    }(0, o.addClass)(this.html, e)
                }, t.prototype.onTouchStart = function(t) {
                    var e = this;
                    this.longTouch = !1, this.touchTimer = setTimeout((function() {
                        e.longTouch = !0
                    }), 150), this.moveX = 0, this.touchstartX = t.touches[0].pageX, this.swipePosXStart = t.touches[0].clientX, this.swipePosYStart = t.touches[0].clientY, clearTimeout(this.timerAutoSlide)
                }, t.prototype.onTouchMove = function(t) {
                    this.touchmoveX = t.touches[0].pageX;
                    var e = this.swipePosXStart - t.touches[0].clientX,
                        i = this.swipePosYStart - t.touches[0].clientY,
                        o = Math.atan2(i, e),
                        s = Math.round(180 * o / Math.PI);
                    (s >= 40 && s <= 140 || s <= -40 && s >= -140) && (this.carouselVerticalScroll = !0), this.carouselVerticalScroll || t.preventDefault(), this.moveX = this.touchstartX - this.touchmoveX
                }, t.prototype.onTouchEnd = function() {
                    clearTimeout(this.touchTimer), this.carouselVerticalScroll = !1, this.moveX > this.sceneSize / 5 ? this.goToNextSlide() : this.moveX < this.sceneSize / 5 * -1 && this.goToPrevSlide(), this.longTouch = !1, (0, o.hasClass)(this.html, "paused") || this.setAutoSlide()
                }, t.prototype.setAnalyticsLink = function(t) {
                    var e = {
                            event: "trackEvent",
                            category: "home page",
                            action: "click",
                            label: ((0, o.hasClass)(t.target, "cta") ? "secondary" : "") + " hero cta",
                            linkUrl: t.target.getAttribute("href"),
                            linkText: t.target.innerText
                        },
                        i = {
                            event: "category_click",
                            module_name: "heroSlider",
                            section_header: (0, o.getClosetSectionHeaderLegacy)(t.target),
                            link_text: t.target.innerText,
                            link_url: t.target.getAttribute("href"),
                            link_type: (0, o.getLinkType)(t.target.getAttribute("href")),
                            category_name: void 0
                        };
                    this.analytics.pushCustomData(e), this.analytics.pushCustomData(i)
                }, t.prototype.setAnalyticsTab = function() {
                    this.analytics.pushCustomData({
                        event: "trackEvent",
                        category: "home page",
                        action: "click",
                        label: "hero content tabs"
                    }, "change tab")
                }, t
            }();
            e.default = r
        },
        451: function(t, e, i) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = function t(e, i, o) {
                var s = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
                if (i <= 0) return void("function" == typeof o && o());
                var n = (e - s) / i * 10;
                setTimeout((function() {
                    document.documentElement.scrollTop = s + n, document.body.scrollTop = s + n, s + n !== e ? t(e, i - 10, o) : "function" == typeof o && o()
                }), 10)
            }
        }
    }
]);